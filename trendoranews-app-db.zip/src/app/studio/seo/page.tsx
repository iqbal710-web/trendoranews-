import Link from "next/link";
import { redirect } from "next/navigation";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { articles, authors, mediaAssets } from "@/db/schema";
import { getUser, isEditor } from "@/lib/auth";
import { isPublished } from "@/lib/queries";
import { SITE_URL } from "@/lib/utils";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function SeoPage() {
  const user = (await getUser())!;
  if (!isEditor(user.role)) redirect("/studio");
  const rows = await db.select({ a: articles, author: authors.name }).from(articles).leftJoin(authors, eq(authors.id, articles.authorId)).where(isPublished()).orderBy(desc(articles.publishedAt)).limit(80);
  const media = await db.select({ alt: mediaAssets.altText, kind: mediaAssets.kind }).from(mediaAssets);
  const imgs = media.filter((m) => m.kind === "image");
  const altOk = imgs.filter((m) => m.alt).length;

  const checks = rows.map(({ a, author }) => {
    const desc2 = a.seoDescription || a.dek;
    const list: [string, boolean][] = [
      ["Headline ≤ 110 chars", a.title.length <= 110],
      ["Image present", !!a.coverImage],
      ["Image alt text", !!a.imageAlt],
      ["Description 70–165", desc2.length >= 70 && desc2.length <= 165],
      ["Author (Person)", !!author],
      ["datePublished", !!a.publishedAt],
      ["Keywords ≥ 2", a.tags.length >= 2],
      ["Sources", a.sources.length > 0],
    ];
    return { a, list, score: list.filter((x) => x[1]).length };
  });
  const perfect = checks.filter((c) => c.score === c.list.length).length;

  return (
    <div>
      <h1 className="h-serif text-3xl font-black">SEO & Google News tools</h1>
      <p className="mb-6 mt-1 text-sm text-muted">Structured-data validation, sitemaps, feeds and Image SEO at a glance.</p>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <div className="panel text-center"><div className="h-serif text-3xl font-black text-brand">{perfect}/{checks.length}</div><div className="text-xs text-muted">Articles passing every structured-data check</div></div>
        <div className="panel text-center"><div className="h-serif text-3xl font-black text-brand">{imgs.length ? Math.round((altOk / imgs.length) * 100) : 100}%</div><div className="text-xs text-muted">Media library images with alt text</div></div>
        <div className="panel text-center"><div className="h-serif text-3xl font-black text-brand">3</div><div className="text-xs text-muted">Schemas per story: NewsArticle · Breadcrumb · Organization</div></div>
        <div className="panel text-center"><div className="h-serif text-3xl font-black text-brand">2</div><div className="text-xs text-muted">Sitemaps: XML + Google News</div></div>
      </div>

      <div className="panel mt-6">
        <h2 className="h-serif mb-2 text-lg font-black">Technical SEO endpoints</h2>
        <div className="flex flex-wrap gap-2 text-sm">{[["/sitemap.xml", "XML sitemap"], ["/news-sitemap.xml", "Google News sitemap"], ["/robots.txt", "robots.txt"], ["/rss.xml", "RSS feed"], ["/rss/technology", "Category RSS"], ["/archive", "Archive pages"]].map(([h, l]) => <Link key={h} href={h} target="_blank" className="btn btn-sm">{l} ↗</Link>)}</div>
        <p className="mt-3 text-xs text-muted">Every page ships a canonical URL, Open Graph + Twitter/X cards, meta title & description. Author, category, tag, country, region and archive pages are all crawlable. Automatic internal-linking suggestions live in each article&apos;s “Checks” tab.</p>
      </div>

      <h2 className="h-serif mb-2 mt-8 text-lg font-black">Structured data validation</h2>
      <div className="overflow-x-auto rounded-xl border border-line bg-card">
        <table className="table-x min-w-[900px]">
          <thead><tr><th>Article</th>{checks[0]?.list.map(([l]) => <th key={l} className="text-center">{l}</th>)}<th>Test</th></tr></thead>
          <tbody>{checks.map(({ a, list, score }) => (
            <tr key={a.id}><td className="max-w-xs"><Link href={`/studio/articles/${a.id}`} className="font-semibold hover:text-brand">{a.title}</Link><div className="text-xs text-muted">{score}/{list.length} checks</div></td>
              {list.map(([l, ok]) => <td key={l} className={`text-center ${ok ? "text-emerald-600" : "text-rose-600"}`}>{ok ? "✓" : "✕"}</td>)}
              <td><a className="text-xs text-brand" target="_blank" rel="noreferrer" href={`https://search.google.com/test/rich-results?url=${encodeURIComponent(`${SITE_URL}/news/${a.slug}`)}`}>Rich results ↗</a></td></tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}
