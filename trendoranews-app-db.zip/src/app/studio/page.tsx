import Link from "next/link";
import type { ReactNode } from "react";
import { and, count, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { articles, events, factChecks, users } from "@/db/schema";
import { canSeeAnalytics, getUser, isAdmin, isEditor } from "@/lib/auth";
import { PUBLISHERS, ROLE_LABEL } from "@/lib/taxonomy";
import { compact } from "@/lib/utils";
import { studioRows } from "@/lib/studio-rows";
import ArticlesTable from "@/components/studio/ArticlesTable";

export const dynamic = "force-dynamic";

const BLURB: Record<string, string> = {
  reporter: "File stories from the field, track review feedback and see what's been published.",
  writer: "Draft features, columns and explainers, and send them for editorial review.",
  editor: "Review submissions, give feedback, approve stories and curate the front page.",
  senior_editor: "Approve, publish and schedule stories, and steer breaking coverage.",
  fact_checker: "Verify claims, set fact-check status on stories and answer reader submissions.",
  publisher: "Own the publishing pipeline, alerts and the performance of the newsroom.",
  admin: "Full control over content, people, media and analytics.",
};

function Section({ title, hint, children, href }: { title: string; hint?: string; children: ReactNode; href?: string }) {
  return (
    <section className="mt-8">
      <div className="mb-3 flex items-end justify-between gap-3"><div><h2 className="h-serif text-xl font-black">{title}</h2>{hint && <p className="text-xs text-muted">{hint}</p>}</div>{href && <Link href={href} className="text-sm font-semibold text-brand">View all →</Link>}</div>
      {children}
    </section>
  );
}

export default async function StudioHome() {
  const user = (await getUser())!;
  const role = user.role;
  const ed = isEditor(role);
  const [byStatus, [{ rt }], [{ v7 }], [{ claims }], mine] = await Promise.all([
    db.select({ s: articles.status, c: count() }).from(articles).groupBy(articles.status),
    db.select({ rt: sql<number>`count(distinct ${events.visitorId})::int` }).from(events).where(gt(events.createdAt, sql`now() - interval '5 minutes'`)),
    db.select({ v7: sql<number>`count(*)::int` }).from(events).where(and(eq(events.type, "pageview"), gt(events.createdAt, sql`now() - interval '7 days'`))),
    db.select({ claims: count() }).from(factChecks).where(eq(factChecks.status, "submitted")),
    studioRows(eq(articles.createdBy, user.id), 8),
  ]);
  const n = (s: string) => Number(byStatus.find((x) => x.s === s)?.c ?? 0);
  const stats: [string, number | string, string][] = ed
    ? [["Awaiting review", n("pending_review"), "/studio/articles?status=pending_review"], ["Approved — ready", n("approved"), "/studio/articles?status=approved"], ["Scheduled", n("scheduled"), "/studio/articles?status=scheduled"], ["Published", n("published"), "/studio/articles?status=published"], ["Drafts", n("draft"), "/studio/articles?status=draft"]]
    : [["My drafts", mine.filter((r) => r.status === "draft").length, "/studio/articles?status=draft"], ["In review", mine.filter((r) => r.status === "pending_review").length, "/studio/articles?status=pending_review"], ["Needs changes", mine.filter((r) => r.status === "rejected").length, "/studio/articles?status=rejected"], ["Published", mine.filter((r) => r.status === "published").length, "/studio/articles?status=published"]];

  const queue = ed ? await studioRows(eq(articles.status, "pending_review"), 10) : [];
  const ready = PUBLISHERS.includes(role) ? await studioRows(eq(articles.status, "approved"), 10) : [];
  const scheduled = PUBLISHERS.includes(role) ? await studioRows(eq(articles.status, "scheduled"), 6) : [];
  const unchecked = role === "fact_checker" || ed ? await studioRows(and(eq(articles.factStatus, "unchecked"), eq(articles.status, "published")), 8) : [];
  const roleCounts = isAdmin(role) ? await db.select({ r: users.role, c: count() }).from(users).groupBy(users.role) : [];

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div><div className="kicker text-brand">{ROLE_LABEL[role]}</div><h1 className="h-serif text-3xl font-black">{ROLE_LABEL[role]} Dashboard</h1><p className="mt-1 max-w-2xl text-sm text-muted">{BLURB[role]}</p></div>
        <div className="flex gap-2">{role !== "fact_checker" && <Link href="/studio/articles/new" className="btn btn-primary">✍️ New article</Link>}<Link href="/studio/live" className="btn">🔴 Live desk</Link></div>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {stats.map(([l, v, h]) => <Link key={l} href={h} className="panel text-center transition hover:border-brand"><div className="h-serif text-3xl font-black text-brand">{v}</div><div className="text-xs text-muted">{l}</div></Link>)}
        {canSeeAnalytics(role) && <Link href="/studio/analytics" className="panel text-center transition hover:border-brand"><div className="h-serif text-3xl font-black text-emerald-600">{rt}</div><div className="text-xs text-muted">Live visitors · {compact(v7)} views/7d</div></Link>}
      </div>

      {role === "fact_checker" && <Section title="Reader claims waiting" hint="Submitted through the Fact Check Center"><Link href="/studio/factchecks" className="panel flex items-center justify-between transition hover:border-brand"><span><b className="text-2xl text-brand">{Number(claims)}</b> claims to review</span><span className="btn btn-sm btn-primary">Open fact-check desk →</span></Link></Section>}
      {unchecked.length > 0 && <Section title="Published stories not yet fact-checked" hint="Set a status right from the table" href="/studio/articles"><ArticlesTable rows={unchecked} role={role} userId={user.id} selectable={false} /></Section>}
      {ed && <Section title="Editorial review queue" hint="Approve, or send back with feedback" href="/studio/articles?status=pending_review"><ArticlesTable rows={queue} role={role} userId={user.id} selectable={false} empty="Nothing waiting for review 🎉" /></Section>}
      {PUBLISHERS.includes(role) && <Section title="Approved — ready to publish" hint="Publish now or schedule from the editor" href="/studio/articles?status=approved"><ArticlesTable rows={ready} role={role} userId={user.id} selectable={false} empty="No approved stories waiting." /></Section>}
      {scheduled.length > 0 && <Section title="Scheduled publishing"><ArticlesTable rows={scheduled} role={role} userId={user.id} selectable={false} /></Section>}
      <Section title="My recent articles" href="/studio/articles?mine=1"><ArticlesTable rows={mine} role={role} userId={user.id} selectable={false} empty="You haven't written anything yet — start a new article." /></Section>
      {roleCounts.length > 0 && <Section title="Team" href="/studio/users"><div className="flex flex-wrap gap-2">{roleCounts.map((r) => <span key={r.r} className="chip">{ROLE_LABEL[r.r]}: <b className="text-brand">{Number(r.c)}</b></span>)}</div></Section>}
    </div>
  );
}
