import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { getUser } from "@/lib/auth";
import { getAuthors } from "@/lib/queries";
import ArticleEditor, { type EditorArticle } from "@/components/studio/ArticleEditor";

export const dynamic = "force-dynamic";

export default async function EditArticle({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = (await getUser())!;
  const [a] = await db.select().from(articles).where(eq(articles.id, Number(id))).limit(1);
  if (!a) notFound();
  const authors = await getAuthors();
  const initial: EditorArticle = {
    id: a.id, slug: a.slug, status: a.status, version: a.version, reviewNote: a.reviewNote, title: a.title, dek: a.dek, body: a.body, coverImage: a.coverImage ?? "", imageAlt: a.imageAlt ?? "",
    imageCredit: a.imageCredit ?? "", category: a.category, subcategory: a.subcategory ?? "", type: a.type, country: a.country ?? "", tags: a.tags, authorId: a.authorId, sources: a.sources,
    seoTitle: a.seoTitle ?? "", seoDescription: a.seoDescription ?? "", isBreaking: a.isBreaking, isFeatured: a.isFeatured, isEditorsChoice: a.isEditorsChoice, isDeveloping: a.isDeveloping,
    isLive: a.isLive, scheduledAt: a.scheduledAt?.toISOString() ?? null, factStatus: a.factStatus, editorialLabel: a.editorialLabel ?? "", corrections: a.corrections,
  };
  return (
    <div>
      <h1 className="h-serif mb-4 text-3xl font-black">Edit article</h1>
      <ArticleEditor key={a.id} initial={initial} me={{ id: user.id, role: user.role, name: user.name }} authors={authors.filter((x) => x.kind !== "photographer").map((x) => ({ id: x.id, name: x.name }))} />
    </div>
  );
}
