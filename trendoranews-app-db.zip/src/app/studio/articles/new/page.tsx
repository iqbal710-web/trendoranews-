import { redirect } from "next/navigation";
import { getUser } from "@/lib/auth";
import { getAuthors } from "@/lib/queries";
import ArticleEditor, { type EditorArticle } from "@/components/studio/ArticleEditor";

export const dynamic = "force-dynamic";

export default async function NewArticle() {
  const user = (await getUser())!;
  if (user.role === "fact_checker") redirect("/studio/articles");
  const authors = await getAuthors();
  const blank: EditorArticle = {
    id: null, slug: "", status: "draft", version: 1, reviewNote: null, title: "", dek: "", body: "", coverImage: "", imageAlt: "", imageCredit: "", category: "bangladesh", subcategory: "",
    type: "news", country: "BD", tags: [], authorId: user.authorId, sources: [], seoTitle: "", seoDescription: "", isBreaking: false, isFeatured: false, isEditorsChoice: false,
    isDeveloping: false, isLive: false, scheduledAt: null, factStatus: "unchecked", editorialLabel: "", corrections: [],
  };
  return (
    <div>
      <h1 className="h-serif mb-4 text-3xl font-black">New article</h1>
      <ArticleEditor initial={blank} me={{ id: user.id, role: user.role, name: user.name }} authors={authors.filter((a) => a.kind !== "photographer").map((a) => ({ id: a.id, name: a.name }))} />
    </div>
  );
}
