import Link from "next/link";
import { and, eq, ilike } from "drizzle-orm";
import { articles } from "@/db/schema";
import { getUser, isEditor } from "@/lib/auth";
import { CATEGORIES } from "@/lib/taxonomy";
import { studioRows } from "@/lib/studio-rows";
import ArticlesTable from "@/components/studio/ArticlesTable";

export const dynamic = "force-dynamic";

const STATUSES = ["draft", "pending_review", "approved", "scheduled", "published", "archived", "rejected"];

export default async function ArticlesPage({ searchParams }: { searchParams: Promise<{ status?: string; category?: string; q?: string; mine?: string }> }) {
  const sp = await searchParams;
  const user = (await getUser())!;
  const seeAll = isEditor(user.role) || user.role === "fact_checker";
  const conds = [
    sp.status ? eq(articles.status, sp.status) : undefined,
    sp.category ? eq(articles.category, sp.category) : undefined,
    sp.q ? ilike(articles.title, `%${sp.q}%`) : undefined,
    !seeAll || sp.mine ? eq(articles.createdBy, user.id) : undefined,
  ].filter(Boolean);
  const rows = await studioRows(conds.length ? and(...conds) : undefined, 100);
  return (
    <div>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div><h1 className="h-serif text-3xl font-black">Articles</h1><p className="text-sm text-muted">{seeAll ? "All stories in the newsroom." : "Your stories."} Select rows for bulk editing.</p></div>
        {user.role !== "fact_checker" && <Link href="/studio/articles/new" className="btn btn-primary">✍️ New article</Link>}
      </div>
      <form className="mb-4 flex flex-wrap gap-2" method="get">
        <input name="q" defaultValue={sp.q} placeholder="Search title…" className="input !w-56" aria-label="Search" />
        <select name="status" defaultValue={sp.status ?? ""} className="input !w-auto" aria-label="Status"><option value="">All statuses</option>{STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}</select>
        <select name="category" defaultValue={sp.category ?? ""} className="input !w-auto" aria-label="Category"><option value="">All categories</option>{CATEGORIES.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select>
        {seeAll && <label className="flex items-center gap-1.5 text-sm"><input type="checkbox" name="mine" value="1" defaultChecked={!!sp.mine} /> Mine only</label>}
        <button className="btn btn-sm">Filter</button>
      </form>
      <ArticlesTable rows={rows} role={user.role} userId={user.id} />
    </div>
  );
}
