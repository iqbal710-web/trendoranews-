import { getUser, isEditor } from "@/lib/auth";
import MediaLibrary from "@/components/studio/MediaLibrary";

export const dynamic = "force-dynamic";

export default async function MediaPage() {
  const user = (await getUser())!;
  return (
    <div>
      <h1 className="h-serif text-3xl font-black">Media library</h1>
      <p className="mb-6 mt-1 text-sm text-muted">Images, videos and audio — with cropping, compression, alt text, metadata and duplicate detection.</p>
      <MediaLibrary canDelete={isEditor(user.role)} />
    </div>
  );
}
