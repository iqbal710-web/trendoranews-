import { redirect } from "next/navigation";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getUser, isAdmin } from "@/lib/auth";
import UsersTable from "@/components/studio/UsersTable";

export const dynamic = "force-dynamic";

export default async function UsersPage() {
  const me = (await getUser())!;
  if (!isAdmin(me.role)) redirect("/studio");
  const rows = await db.select().from(users).orderBy(desc(users.createdAt));
  return (
    <div>
      <h1 className="h-serif text-3xl font-black">Users & roles</h1>
      <p className="mb-6 mt-1 text-sm text-muted">Promote readers to reporters, editors, fact-checkers and more. Roles control which dashboards and actions people get.</p>
      <UsersTable meId={me.id} rows={rows.map((u) => ({ id: u.id, name: u.name, email: u.email, role: u.role, createdAt: u.createdAt.toISOString(), google: !!u.googleId }))} />
    </div>
  );
}
