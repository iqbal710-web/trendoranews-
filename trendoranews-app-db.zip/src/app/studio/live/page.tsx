import { desc, eq, or } from "drizzle-orm";
import { db } from "@/db";
import { alerts, articles, liveUpdates } from "@/db/schema";
import { getUser, isEditor } from "@/lib/auth";
import LiveManager from "@/components/studio/LiveManager";

export const dynamic = "force-dynamic";

export default async function LiveDesk({ searchParams }: { searchParams: Promise<{ article?: string }> }) {
  const { article } = await searchParams;
  const user = (await getUser())!;
  const list = await db.select({ id: articles.id, title: articles.title, slug: articles.slug, isLive: articles.isLive, isDeveloping: articles.isDeveloping, isBreaking: articles.isBreaking, type: articles.type }).from(articles).where(or(eq(articles.isLive, true), eq(articles.type, "live"), eq(articles.isDeveloping, true))).orderBy(desc(articles.updatedAt)).limit(12);
  const selected = list.find((a) => a.id === Number(article)) ?? list[0] ?? null;
  const ups = selected ? await db.select().from(liveUpdates).where(eq(liveUpdates.articleId, selected.id)).orderBy(desc(liveUpdates.createdAt)) : [];
  const al = await db.select().from(alerts).orderBy(desc(alerts.createdAt)).limit(10);
  return (
    <div>
      <h1 className="h-serif text-3xl font-black">Live desk & alerts</h1>
      <p className="mb-6 mt-1 text-sm text-muted">Run live blogs, manage developing stories, and broadcast breaking or emergency alerts.</p>
      <LiveManager
        articles={list}
        selected={selected}
        updates={ups.map((u) => ({ id: u.id, title: u.title, body: u.body, kind: u.kind, pinned: u.pinned, createdAt: u.createdAt.toISOString(), authorName: u.authorName }))}
        alerts={al.map((a) => ({ id: a.id, level: a.level, headline: a.headline, active: a.active, expiresAt: a.expiresAt?.toISOString() ?? null, createdAt: a.createdAt.toISOString() }))}
        ed={isEditor(user.role)}
      />
    </div>
  );
}
