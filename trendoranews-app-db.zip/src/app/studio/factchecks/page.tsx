import { redirect } from "next/navigation";
import { asc, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { factChecks } from "@/db/schema";
import { canFactCheck, getUser } from "@/lib/auth";
import FactCheckManager from "@/components/studio/FactCheckManager";

export const dynamic = "force-dynamic";

export default async function FactChecksPage() {
  const user = (await getUser())!;
  if (!canFactCheck(user.role)) redirect("/studio");
  const rows = await db.select().from(factChecks).orderBy(asc(sql`case when ${factChecks.status} = 'submitted' then 0 else 1 end`), desc(factChecks.createdAt));
  return (
    <div>
      <h1 className="h-serif text-3xl font-black">Fact-check desk</h1>
      <p className="mb-6 mt-1 text-sm text-muted">Review claims submitted by readers, write verdicts and publish them to the public Fact Check Center.</p>
      <FactCheckManager items={rows.map((r) => ({ id: r.id, claim: r.claim, verdict: r.verdict, explanation: r.explanation, sourceTitle: r.sources[0]?.title ?? "", sourceUrl: r.sources[0]?.url ?? "", status: r.status, submittedBy: r.submittedBy, createdAt: r.createdAt.toISOString() }))} />
    </div>
  );
}
