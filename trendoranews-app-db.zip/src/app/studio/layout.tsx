import type { Metadata } from "next";
import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { ensureSeeded } from "@/db/seed";
import { canFactCheck, canSeeAnalytics, getUser, isAdmin, isEditor, isStaff } from "@/lib/auth";
import { ROLE_LABEL } from "@/lib/taxonomy";
import StudioNav, { type NavItem } from "@/components/studio/StudioNav";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: { default: "Newsroom Studio", template: "%s | TrendoraNews Studio" }, robots: { index: false, follow: false } };

export default async function StudioLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const user = await getUser();
  if (!user) redirect("/login?next=/studio");
  if (!isStaff(user.role)) redirect("/dashboard");
  const items: NavItem[] = [
    { href: "/studio", label: "Dashboard", icon: "🏠" },
    { href: "/studio/articles", label: "Articles", icon: "📰" },
    ...(user.role !== "fact_checker" ? [{ href: "/studio/articles/new", label: "New article", icon: "✍️" }] : []),
    { href: "/studio/live", label: "Live & alerts", icon: "🔴" },
    ...(canFactCheck(user.role) ? [{ href: "/studio/factchecks", label: "Fact checks", icon: "✅" }] : []),
    { href: "/studio/media", label: "Media library", icon: "🖼️" },
    ...(isEditor(user.role) ? [{ href: "/studio/seo", label: "SEO tools", icon: "🔍" }] : []),
    ...(canSeeAnalytics(user.role) ? [{ href: "/studio/analytics", label: "Analytics", icon: "📊" }] : []),
    ...(isAdmin(user.role) ? [{ href: "/studio/users", label: "Users & roles", icon: "👥" }] : []),
  ];
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[250px_minmax(0,1fr)]">
      <StudioNav items={items} name={user.name} roleLabel={ROLE_LABEL[user.role]} />
      <main className="min-w-0 p-4 sm:p-6 lg:p-8">{children}</main>
    </div>
  );
}
