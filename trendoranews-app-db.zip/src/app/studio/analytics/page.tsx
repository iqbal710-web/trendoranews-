import Link from "next/link";
import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { canSeeAnalytics, getUser } from "@/lib/auth";
import { getAnalytics } from "@/lib/analytics";
import { CAT_MAP } from "@/lib/taxonomy";
import { compact, flag } from "@/lib/utils";
import Realtime from "@/components/studio/Realtime";

export const dynamic = "force-dynamic";

function Card({ title, children, className = "" }: { title: string; children: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}><h2 className="h-serif mb-3 text-lg font-black">{title}</h2>{children}</section>;
}
function Bars({ rows, fmt = (c: number) => compact(c), label = (k: string) => k }: { rows: { k: string; c: number }[]; fmt?: (n: number) => string; label?: (k: string) => string }) {
  const max = Math.max(1, ...rows.map((r) => r.c));
  return <div className="space-y-2">{rows.map((r) => <div key={r.k} className="text-sm"><div className="mb-0.5 flex justify-between"><span className="truncate">{label(r.k)}</span><b>{fmt(r.c)}</b></div><div className="h-2 rounded-full bg-soft"><div className="h-full rounded-full bg-brand" style={{ width: `${(r.c / max) * 100}%` }} /></div></div>)}{!rows.length && <p className="text-sm text-muted">No data yet.</p>}</div>;
}
const delta = (cur: number, prev: number) => (prev ? Math.round(((cur - prev) / prev) * 100) : 0);
const Delta = ({ v }: { v: number }) => <span className={`text-xs font-bold ${v >= 0 ? "text-emerald-600" : "text-rose-600"}`}>{v >= 0 ? "▲" : "▼"} {Math.abs(v)}%</span>;
const mmss = (s: number) => `${Math.floor(s / 60)}m ${String(s % 60).padStart(2, "0")}s`;

export default async function AnalyticsPage() {
  const user = (await getUser())!;
  if (!canSeeAnalytics(user.role)) redirect("/studio");
  const a = await getAnalytics();
  const t = a.totals;
  const maxPv = Math.max(1, ...a.daily.map((d) => d.pv));
  const W = 700, H = 180;
  const pts = a.daily.map((d, i) => `${20 + (i / Math.max(1, a.daily.length - 1)) * (W - 40)},${H - 20 - (d.uv / maxPv) * (H - 40)}`).join(" ");
  const ret = a.retention;

  return (
    <div className="space-y-6">
      <div><h1 className="h-serif text-3xl font-black">Analytics</h1><p className="mt-1 text-sm text-muted">Last 30 days · tracked first-party from every page and article read.</p></div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Realtime initial={a.rt} />
        <div className="panel"><div className="kicker text-muted">Total page views</div><div className="h-serif text-4xl font-black">{compact(t.pv)}</div><Delta v={delta(t.pv, t.pv_prev)} /> <span className="text-xs text-muted">vs previous 30 days</span></div>
        <div className="panel"><div className="kicker text-muted">Unique visitors</div><div className="h-serif text-4xl font-black">{compact(t.uv)}</div><Delta v={delta(t.uv, t.uv_prev)} /> <span className="text-xs text-muted">vs previous 30 days</span></div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="panel"><div className="kicker text-muted">Returning visitors</div><div className="h-serif text-3xl font-black">{compact(t.rv)}</div><div className="text-xs text-muted">{t.uv ? Math.round((t.rv / t.uv) * 100) : 0}% of unique · {t.uv - t.rv} new</div></div>
        <div className="panel"><div className="kicker text-muted">Avg. reading time</div><div className="h-serif text-3xl font-black">{mmss(a.reading.avg)}</div><div className="text-xs text-muted">across {compact(a.reading.n)} article reads</div></div>
        <div className="panel"><div className="kicker text-muted">Newsletter subscribers</div><div className="h-serif text-3xl font-black">{a.newsletter.total}</div><div className="text-xs text-muted">+{a.newsletter.new7} this week · +{a.newsletter.new30} this month</div></div>
        <div className="panel"><div className="kicker text-muted">Video views</div><div className="h-serif text-3xl font-black">{compact(a.videos.reduce((s, v) => s + v.total, 0))}</div><div className="text-xs text-muted">{a.videos.reduce((s, v) => s + v.d30, 0)} tracked in last 30 days</div></div>
      </div>

      <Card title="Daily traffic — page views (bars) & unique visitors (line)">
        <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" role="img" aria-label="Daily traffic chart">
          {a.daily.map((d, i) => { const w = (W - 40) / a.daily.length; return <rect key={d.d} x={20 + i * w + 1} y={H - 20 - (d.pv / maxPv) * (H - 40)} width={Math.max(2, w - 2)} height={(d.pv / maxPv) * (H - 40)} className="fill-brand/60"><title>{d.d}: {d.pv} views, {d.uv} visitors</title></rect>; })}
          <polyline points={pts} fill="none" className="stroke-sky-500" strokeWidth={2.5} />
          {[0, Math.floor(a.daily.length / 2), a.daily.length - 1].map((i) => a.daily[i] && <text key={i} x={20 + (i / Math.max(1, a.daily.length - 1)) * (W - 40)} y={H - 4} textAnchor="middle" className="fill-muted text-[10px]">{a.daily[i].d}</text>)}
        </svg>
      </Card>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Traffic sources"><Bars rows={a.sources} /></Card>
        <Card title="Country-wise visitors"><Bars rows={a.countries} label={(k) => `${k.length === 2 ? flag(k) : "🌐"} ${k}`} /></Card>
        <Card title="Device statistics"><Bars rows={a.devices} label={(k) => `${k === "Mobile" ? "📱" : k === "Desktop" ? "🖥" : "📟"} ${k}`} /></Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Most popular articles"><ol className="space-y-2 text-sm">{a.popular.map((p, i) => <li key={p.id} className="flex gap-3"><b className="w-5 text-brand">{i + 1}</b><Link href={`/news/${p.slug}`} className="flex-1 hover:text-brand">{p.title}</Link><span className="font-bold">{compact(p.c)}</span></li>)}</ol></Card>
        <Card title="Trending categories (7d vs prior 7d)"><div className="space-y-2 text-sm">{a.trending.map((c) => { const d = delta(c.cur, c.prev); return <div key={c.k} className="flex items-center justify-between"><span>{CAT_MAP[c.k]?.emoji} {CAT_MAP[c.k]?.name ?? c.k}</span><span><b>{c.cur}</b> views <Delta v={d} /></span></div>; })}</div></Card>
      </div>

      <Card title="Article engagement (likes · shares · comments · saves per read)">
        <div className="overflow-x-auto"><table className="table-x min-w-[600px]"><thead><tr><th>Article</th><th className="text-right">Reads</th><th className="text-right">Likes</th><th className="text-right">Shares</th><th className="text-right">Comments</th><th className="text-right">Saves</th><th className="text-right">Rate</th></tr></thead>
          <tbody>{a.engagement.map((e) => <tr key={e.id}><td className="max-w-xs"><Link href={`/news/${e.slug}`} className="hover:text-brand">{e.title}</Link></td><td className="text-right">{compact(e.views)}</td><td className="text-right">{e.likes}</td><td className="text-right">{e.shares}</td><td className="text-right">{e.comments}</td><td className="text-right">{e.saves}</td><td className="text-right font-bold text-brand">{(((e.likes + e.shares + e.comments * 3 + e.saves * 2) / Math.max(1, e.views)) * 100).toFixed(1)}%</td></tr>)}</tbody></table></div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="User retention">
          <div className="space-y-3 text-sm">{[["Day 1 return", ret?.d1 ?? 0], ["Day 7 return", ret?.d7 ?? 0]].map(([l, v]) => { const pct = ret?.total ? Math.round((Number(v) / ret.total) * 100) : 0; return <div key={l as string}><div className="mb-0.5 flex justify-between"><span>{l}</span><b>{pct}%</b></div><div className="h-2.5 rounded-full bg-soft"><div className="h-full rounded-full bg-emerald-500" style={{ width: `${pct}%` }} /></div></div>; })}<p className="text-xs text-muted">Of {ret?.total ?? 0} visitors first seen over 7 days ago, the share who came back later.</p></div>
        </Card>
        <Card title="Video views"><Bars rows={a.videos.map((v) => ({ k: v.title.slice(0, 34), c: v.total }))} /></Card>
        <Card title={`Search analytics (${a.searchTotal} searches)`}>
          <div className="space-y-1 text-sm">{a.topSearch.map((s) => <div key={s.q} className="flex justify-between"><span>🔎 {s.q}</span><span className="text-muted"><b className="text-ink">{s.c}</b> · ~{s.r} results</span></div>)}</div>
          {a.zeroSearch.length > 0 && <div className="mt-3 rounded-lg bg-amber-500/10 p-2 text-xs"><b>Zero-result queries (content gaps):</b> {a.zeroSearch.map((z) => `${z.q} (${z.c})`).join(", ")}</div>}
        </Card>
      </div>

      <Card title="Content performance (30 days)">
        <div className="overflow-x-auto"><table className="table-x min-w-[600px]"><thead><tr><th>Article</th><th>Section</th><th className="text-right">Page views</th><th className="text-right">Avg. read</th><th className="text-right">Read-through</th></tr></thead>
          <tbody>{a.performance.map((p) => <tr key={p.id}><td className="max-w-xs"><Link href={`/news/${p.slug}`} className="hover:text-brand">{p.title}</Link></td><td className="capitalize">{p.category}</td><td className="text-right">{p.pv}</td><td className="text-right">{p.avg_s ? mmss(p.avg_s) : "—"}</td><td className="text-right font-bold text-brand">{p.pv ? Math.round((p.reads / p.pv) * 100) : 0}%</td></tr>)}</tbody></table></div>
      </Card>
    </div>
  );
}
