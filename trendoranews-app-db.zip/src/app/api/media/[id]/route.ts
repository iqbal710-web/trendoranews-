import type { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { mediaAssets } from "@/db/schema";
import { isEditor, requireStaff } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [m] = await db.select().from(mediaAssets).where(eq(mediaAssets.id, Number(id))).limit(1);
  if (!m) return new Response("Not found", { status: 404 });
  if (!m.data) return m.url ? Response.redirect(m.url, 302) : new Response("Not found", { status: 404 });
  return new Response(new Uint8Array(Buffer.from(m.data, "base64")), { headers: { "Content-Type": m.mime || "application/octet-stream", "Cache-Control": "public, max-age=31536000, immutable" } });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireStaff();
  if (!user) return Response.json({ message: "Not allowed" }, { status: 403 });
  const { id } = await params;
  const b = await req.json().catch(() => ({}));
  const patch: Partial<typeof mediaAssets.$inferInsert> = {};
  if (b.altText !== undefined) patch.altText = String(b.altText).slice(0, 300) || null;
  if (b.title !== undefined) patch.title = String(b.title).slice(0, 160);
  if (b.credit !== undefined) patch.credit = String(b.credit).slice(0, 160) || null;
  if (Array.isArray(b.tags)) patch.tags = b.tags.map(String).slice(0, 10);
  await db.update(mediaAssets).set(patch).where(eq(mediaAssets.id, Number(id)));
  return Response.json({ ok: true });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireStaff();
  if (!user || !isEditor(user.role)) return Response.json({ message: "Only editors can delete media." }, { status: 403 });
  const { id } = await params;
  await db.delete(mediaAssets).where(eq(mediaAssets.id, Number(id)));
  return Response.json({ ok: true });
}
