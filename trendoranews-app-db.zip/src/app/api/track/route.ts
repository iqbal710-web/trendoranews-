import type { NextRequest } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { articles, events, readingHistory, videos } from "@/db/schema";
import { getUser } from "@/lib/auth";

function source(ref: string) {
  const r = (ref || "").toLowerCase();
  if (!r) return "Direct";
  if (r.includes("google")) return "Google";
  if (r.includes("facebook") || r.includes("fb.")) return "Facebook";
  if (r === "t.co" || r.includes("twitter") || r.startsWith("x.com")) return "X / Twitter";
  if (r.includes("bing")) return "Bing";
  if (r.includes("youtube")) return "YouTube";
  if (r.includes("mail") || r.includes("newsletter")) return "Newsletter";
  return "Referral";
}

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => null);
  if (!b || !b.vid || !b.type) return Response.json({ ok: false }, { status: 400 });
  const h = req.headers;
  const ua = h.get("user-agent") || "";
  const device = /ipad|tablet/i.test(ua) ? "Tablet" : /mobi|android|iphone/i.test(ua) ? "Mobile" : "Desktop";
  const al = (h.get("accept-language") || "").match(/-([A-Z]{2})/);
  const country = h.get("x-vercel-ip-country") || h.get("cf-ipcountry") || (al ? al[1] : "Unknown");
  const user = await getUser();
  const path = String(b.path || "/").slice(0, 200);

  let articleId: number | null = b.articleId ? Number(b.articleId) : null;
  let category: string | null = null;
  const m = path.match(/^\/news\/([^/?#]+)/);
  if (m || articleId) {
    const row = await db.select({ id: articles.id, category: articles.category }).from(articles).where(articleId ? eq(articles.id, articleId) : eq(articles.slug, decodeURIComponent(m![1]))).limit(1);
    if (row[0]) {
      articleId = row[0].id;
      category = row[0].category;
    }
  }
  const type = String(b.type);
  if (!["pageview", "read", "video_view"].includes(type)) return Response.json({ ok: false }, { status: 400 });

  await db.insert(events).values({
    type, path, articleId, videoId: b.videoId ? Number(b.videoId) : null, category, visitorId: String(b.vid).slice(0, 64), userId: user?.id ?? null,
    country, device, source: source(String(b.ref || "")), isReturning: !!b.returning, seconds: Math.min(3600, Math.max(0, Number(b.seconds) || 0)),
  });

  if (type === "pageview" && articleId && m) await db.update(articles).set({ views: sql`${articles.views} + 1` }).where(eq(articles.id, articleId));
  if (type === "video_view" && b.videoId) await db.update(videos).set({ views: sql`${videos.views} + 1` }).where(eq(videos.id, Number(b.videoId)));
  if (type === "read" && user && articleId) {
    const progress = Math.min(100, Math.max(0, Number(b.progress) || 0));
    await db
      .insert(readingHistory)
      .values({ userId: user.id, articleId, progress, seconds: Number(b.seconds) || 0 })
      .onConflictDoUpdate({
        target: [readingHistory.userId, readingHistory.articleId],
        set: { progress: sql`greatest(${readingHistory.progress}, ${progress})`, seconds: sql`${readingHistory.seconds} + ${Number(b.seconds) || 0}`, viewedAt: new Date() },
      });
  }
  void and;
  return Response.json({ ok: true });
}
