import { NextRequest, NextResponse } from "next/server";

// Google OAuth: set GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET / NEXTAUTH-style redirect in env.
// If unconfigured we return a helpful message so the UI can show it.
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const redirectUri =
    process.env.GOOGLE_REDIRECT_URI ||
    `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/api/auth/google/callback`;
  if (!clientId || clientId === "your-google-client-id") {
    return NextResponse.json({
      configured: false,
      message:
        "Google sign-in is ready but needs GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env. Use email sign-in meanwhile.",
    }, { status: 200 });
  }
  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  url.searchParams.set("client_id", clientId);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "openid email profile");
  url.searchParams.set("state", req.nextUrl.searchParams.get("state") ?? "google");
  url.searchParams.set("prompt", "select_account");
  return NextResponse.redirect(url.toString());
}
