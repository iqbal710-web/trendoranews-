import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession } from "@/lib/auth";
import { originOf } from "@/lib/origin";

export async function GET(req: NextRequest) {
  const origin = originOf(req);
  const fail = (e: string) => NextResponse.redirect(`${origin}/login?error=${e}`);
  const code = req.nextUrl.searchParams.get("code");
  const state = req.nextUrl.searchParams.get("state");
  if (!code || !state || state !== req.cookies.get("tn_oauth_state")?.value) return fail("google_state");
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: process.env.GOOGLE_CLIENT_ID || "",
      client_secret: process.env.GOOGLE_CLIENT_SECRET || "",
      redirect_uri: `${origin}/api/auth/google/callback`,
      grant_type: "authorization_code",
    }),
  });
  if (!tokenRes.ok) return fail("google_token");
  const tok = await tokenRes.json();
  const infoRes = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", { headers: { Authorization: `Bearer ${tok.access_token}` } });
  if (!infoRes.ok) return fail("google_profile");
  const info = await infoRes.json();
  const email = String(info.email || "").toLowerCase();
  if (!email) return fail("google_profile");
  let rows = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!rows[0]) {
    rows = await db.insert(users).values({ name: info.name || email.split("@")[0], email, googleId: info.sub, avatar: info.picture ?? null, role: "reader" }).returning();
  } else if (!rows[0].googleId) {
    await db.update(users).set({ googleId: info.sub, avatar: rows[0].avatar ?? info.picture ?? null }).where(eq(users.id, rows[0].id));
  }
  await createSession(rows[0].id);
  const res = NextResponse.redirect(`${origin}/dashboard`);
  res.cookies.delete("tn_oauth_state");
  return res;
}
