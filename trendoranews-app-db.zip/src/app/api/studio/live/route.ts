import type { NextRequest } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { alerts, articles, liveUpdates } from "@/db/schema";
import { isEditor, requireStaff } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const user = await requireStaff();
  if (!user) return Response.json({ message: "Not allowed" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const ed = isEditor(user.role);
  const deny = () => Response.json({ ok: false, message: "Only editors can do that." }, { status: 403 });
  const ok = (message: string) => Response.json({ ok: true, message });

  switch (b.action) {
    case "addUpdate": {
      const title = String(b.title || "").trim().slice(0, 200);
      if (!title || !b.articleId) return Response.json({ ok: false, message: "Add a headline for the update." }, { status: 400 });
      await db.insert(liveUpdates).values({ articleId: Number(b.articleId), title, body: String(b.body || "").slice(0, 3000), kind: ["update", "alert", "correction", "media"].includes(b.kind) ? b.kind : "update", pinned: !!b.pinned && ed, imageUrl: b.imageUrl ? String(b.imageUrl).slice(0, 600) : null, authorName: user.name });
      await db.update(articles).set({ updatedAt: new Date() }).where(eq(articles.id, Number(b.articleId)));
      return ok("Update posted — readers see it within 15 seconds.");
    }
    case "deleteUpdate":
      if (!ed) return deny();
      await db.delete(liveUpdates).where(eq(liveUpdates.id, Number(b.id)));
      return ok("Update removed.");
    case "togglePin":
      if (!ed) return deny();
      await db.update(liveUpdates).set({ pinned: sql`not ${liveUpdates.pinned}` }).where(eq(liveUpdates.id, Number(b.id)));
      return ok("Pin toggled.");
    case "setFlag": {
      if (!ed) return deny();
      const flag = String(b.flag);
      const patch: Partial<typeof articles.$inferInsert> = { updatedAt: new Date() };
      if (flag === "isLive") patch.isLive = !!b.value;
      else if (flag === "isDeveloping") patch.isDeveloping = !!b.value;
      else if (flag === "isBreaking") { patch.isBreaking = !!b.value; patch.breakingUntil = b.value ? new Date(Date.now() + (Number(b.hours) || 6) * 3600_000) : null; }
      else return Response.json({ ok: false, message: "Unknown flag" }, { status: 400 });
      await db.update(articles).set(patch).where(eq(articles.id, Number(b.articleId)));
      return ok("Updated.");
    }
    case "sendAlert": {
      if (!ed) return deny();
      const headline = String(b.headline || "").trim().slice(0, 240);
      if (headline.length < 5) return Response.json({ ok: false, message: "Write the alert headline." }, { status: 400 });
      const level = ["breaking", "emergency", "info"].includes(b.level) ? b.level : "breaking";
      const [a] = await db.insert(alerts).values({ level, headline, articleId: b.articleId ? Number(b.articleId) : null, expiresAt: new Date(Date.now() + (Number(b.hours) || 12) * 3600_000) }).returning({ id: alerts.id });
      if (b.push !== false) {
        let href = "/live";
        if (b.articleId) { const [r] = await db.select({ slug: articles.slug }).from(articles).where(eq(articles.id, Number(b.articleId))).limit(1); if (r) href = `/news/${r.slug}`; }
        await db.execute(sql`insert into notifications (user_id, title, body, href, kind) select id, ${level === "emergency" ? "Emergency alert" : "Breaking"}, ${headline}, ${href}, ${level === "emergency" ? "emergency" : "breaking"} from users`);
      }
      return Response.json({ ok: true, message: "Alert sent: banner live on the site, in-app notifications queued, browser notifications fire for open tabs.", id: a.id });
    }
    case "expireAlert":
      if (!ed) return deny();
      await db.update(alerts).set({ active: false }).where(eq(alerts.id, Number(b.id)));
      return ok("Alert expired.");
    default:
      return Response.json({ ok: false, message: "Unknown action" }, { status: 400 });
  }
}
