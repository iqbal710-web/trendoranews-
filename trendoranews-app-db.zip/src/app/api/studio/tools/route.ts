import type { NextRequest } from "next/server";
import { and, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { requireStaff } from "@/lib/auth";
import { isPublished } from "@/lib/queries";
import { listVersions } from "@/lib/studio";
import { similarity, titleKey } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const user = await requireStaff();
  if (!user) return Response.json({ message: "Not allowed" }, { status: 403 });
  const sp = req.nextUrl.searchParams;
  const id = Number(sp.get("id")) || 0;
  if (sp.get("kind") === "versions") return Response.json({ versions: id ? await listVersions(id) : [] });
  if (sp.get("kind") === "duplicates") {
    const key = titleKey(sp.get("title") || "");
    if (key.split(" ").length < 3) return Response.json({ duplicates: [] });
    const rows = await db.select({ id: articles.id, title: articles.title, slug: articles.slug, titleKey: articles.titleKey, status: articles.status }).from(articles).where(id ? ne(articles.id, id) : undefined).limit(800);
    const duplicates = rows.map((r) => ({ id: r.id, title: r.title, slug: r.slug, status: r.status, score: Math.round(similarity(key, r.titleKey) * 100) })).filter((r) => r.score >= 50).sort((a, b) => b.score - a.score).slice(0, 5);
    return Response.json({ duplicates });
  }
  return Response.json({});
}

export async function POST(req: NextRequest) {
  const user = await requireStaff();
  if (!user) return Response.json({ message: "Not allowed" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  if (b.kind === "links") {
    const body = String(b.body || "").toLowerCase();
    if (body.length < 80) return Response.json({ suggestions: [] });
    const rows = await db.select({ id: articles.id, title: articles.title, slug: articles.slug, tags: articles.tags }).from(articles).where(and(isPublished(), b.id ? ne(articles.id, Number(b.id)) : eq(articles.status, "published"))).limit(400);
    const suggestions = rows
      .map((r) => {
        const matched = r.tags.filter((t) => t.length > 3 && body.includes(t));
        const words = r.title.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 5 && body.includes(w));
        return { title: r.title, slug: r.slug, matched: [...new Set([...matched, ...words.slice(0, 2)])], score: matched.length * 2 + words.length };
      })
      .filter((r) => r.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 6);
    return Response.json({ suggestions });
  }
  return Response.json({});
}
