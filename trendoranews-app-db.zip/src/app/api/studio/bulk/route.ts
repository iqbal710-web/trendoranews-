import type { NextRequest } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { isEditor, requireStaff } from "@/lib/auth";
import { applyAction } from "@/lib/studio";
import { CAT_MAP } from "@/lib/taxonomy";

export async function POST(req: NextRequest) {
  const user = await requireStaff();
  if (!user) return Response.json({ message: "Not allowed" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const ids: number[] = (b.ids ?? []).map(Number).filter(Boolean);
  if (!ids.length) return Response.json({ message: "Select at least one article." }, { status: 400 });
  const action = String(b.action);
  const rows = await db.select().from(articles).where(inArray(articles.id, ids));
  let done = 0;
  const errors: string[] = [];
  if (["publish", "unpublish", "archive", "delete", "approve", "submit"].includes(action)) {
    for (const a of rows) {
      const r = await applyAction(user, a, action);
      if (r.ok) done++;
      else errors.push(`“${a.title.slice(0, 40)}”: ${r.message}`);
    }
  } else {
    if (!isEditor(user.role)) return Response.json({ message: "Only editors can bulk edit." }, { status: 403 });
    const patch: Partial<typeof articles.$inferInsert> | null =
      action === "feature" ? { isFeatured: true } :
      action === "unfeature" ? { isFeatured: false } :
      action === "editors" ? { isEditorsChoice: true } :
      action === "uneditors" ? { isEditorsChoice: false } :
      action === "category" && CAT_MAP[String(b.value)] ? { category: String(b.value), subcategory: null } :
      action === "developing" ? { isDeveloping: true } : null;
    if (!patch) return Response.json({ message: "Unknown bulk action." }, { status: 400 });
    for (const a of rows) { await db.update(articles).set({ ...patch, updatedAt: new Date() }).where(eq(articles.id, a.id)); done++; }
  }
  return Response.json({ ok: errors.length === 0 || done > 0, message: `${done} of ${rows.length} updated.${errors.length ? ` ${errors.slice(0, 2).join(" · ")}` : ""}` });
}
