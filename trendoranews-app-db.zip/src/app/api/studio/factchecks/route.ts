import type { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { factChecks } from "@/db/schema";
import { canFactCheck, requireStaff } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const user = await requireStaff();
  if (!user || !canFactCheck(user.role)) return Response.json({ ok: false, message: "Only fact-checkers and editors can do that." }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const claim = String(b.claim || "").trim().slice(0, 500);
  if (claim.length < 5) return Response.json({ ok: false, message: "Claim text is required." }, { status: 400 });
  const verdict = ["true", "mostly-true", "misleading", "false", "unproven"].includes(b.verdict) ? b.verdict : "unproven";
  const publish = b.status === "published";
  if (publish && String(b.explanation || "").trim().length < 20) return Response.json({ ok: false, message: "Write an explanation (20+ characters) before publishing." }, { status: 400 });
  const values = {
    claim, verdict, explanation: String(b.explanation || "").slice(0, 4000), category: b.category ? String(b.category) : null,
    sources: b.sourceUrl ? [{ title: String(b.sourceTitle || b.sourceUrl).slice(0, 200), url: String(b.sourceUrl).slice(0, 500) }] : [],
    status: publish ? "published" : "submitted", checkedBy: user.name,
  };
  if (b.id) await db.update(factChecks).set(values).where(eq(factChecks.id, Number(b.id)));
  else await db.insert(factChecks).values(values);
  return Response.json({ ok: true, message: publish ? "Fact-check published." : "Saved as draft." });
}

export async function DELETE(req: NextRequest) {
  const user = await requireStaff();
  if (!user || !canFactCheck(user.role)) return Response.json({ ok: false, message: "Not allowed" }, { status: 403 });
  const id = Number(req.nextUrl.searchParams.get("id"));
  await db.delete(factChecks).where(eq(factChecks.id, id));
  return Response.json({ ok: true, message: "Deleted." });
}
