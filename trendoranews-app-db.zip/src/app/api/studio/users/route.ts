import type { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getUser, isAdmin } from "@/lib/auth";
import { ROLES } from "@/lib/taxonomy";

export async function PATCH(req: NextRequest) {
  const me = await getUser();
  if (!me || !isAdmin(me.role)) return Response.json({ ok: false, message: "Admins only." }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const id = Number(b.id);
  if (id === me.id) return Response.json({ ok: false, message: "You can't change your own role." }, { status: 400 });
  if (!ROLES.includes(b.role)) return Response.json({ ok: false, message: "Invalid role." }, { status: 400 });
  await db.update(users).set({ role: b.role }).where(eq(users.id, id));
  return Response.json({ ok: true, message: "Role updated." });
}
