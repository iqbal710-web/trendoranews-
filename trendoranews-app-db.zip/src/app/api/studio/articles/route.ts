import type { NextRequest } from "next/server";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { requireStaff, isEditor } from "@/lib/auth";
import { cleanInput, uniqueSlug } from "@/lib/studio";
import { CATEGORIES } from "@/lib/taxonomy";

export async function POST(req: NextRequest) {
  const user = await requireStaff();
  if (!user) return Response.json({ message: "Not allowed" }, { status: 403 });
  if (user.role === "fact_checker") return Response.json({ message: "Fact-checkers can't create articles." }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const input = cleanInput(user, b);
  const title = input.title || "Untitled story";
  const slug = await uniqueSlug(title);
  const [row] = await db
    .insert(articles)
    .values({
      ...input,
      title,
      slug,
      category: input.category ?? CATEGORIES[0].slug,
      status: "draft",
      createdBy: user.id,
      authorId: input.authorId ?? user.authorId ?? null,
    } as typeof articles.$inferInsert)
    .returning({ id: articles.id, slug: articles.slug });
  void isEditor;
  return Response.json({ ok: true, id: row.id, slug: row.slug });
}
