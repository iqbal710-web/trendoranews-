import type { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { requireStaff } from "@/lib/auth";
import { applyAction, canEdit, cleanInput, snapshot, uniqueSlug } from "@/lib/studio";

async function load(id: string) {
  const [a] = await db.select().from(articles).where(eq(articles.id, Number(id))).limit(1);
  return a;
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireStaff();
  const { id } = await params;
  const a = await load(id);
  if (!user || !a) return Response.json({ message: "Not found" }, { status: 404 });
  if (!canEdit(user, a)) return Response.json({ message: "You can't edit this article." }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const input = cleanInput(user, b);
  const patch: Partial<typeof articles.$inferInsert> = { ...input, updatedAt: new Date() };
  if (input.title && a.status !== "published" && input.title !== a.title) patch.slug = await uniqueSlug(input.title, a.id);
  if (!b.autosave) patch.version = a.version + 1;
  const [row] = await db.update(articles).set(patch).where(eq(articles.id, a.id)).returning();
  if (!b.autosave) await snapshot({ id: row.id, title: row.title, dek: row.dek, body: row.body }, row.version, user.name, String(b.note || "Manual save").slice(0, 200));
  return Response.json({ ok: true, slug: row.slug, version: row.version, updatedAt: row.updatedAt.toISOString(), status: row.status });
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireStaff();
  const { id } = await params;
  const a = await load(id);
  if (!user || !a) return Response.json({ message: "Not found" }, { status: 404 });
  const b = await req.json().catch(() => ({}));
  const r = await applyAction(user, a, String(b.action), b);
  return Response.json(r, { status: r.ok ? 200 : 400 });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await requireStaff();
  const { id } = await params;
  const a = await load(id);
  if (!user || !a) return Response.json({ message: "Not found" }, { status: 404 });
  const r = await applyAction(user, a, "delete");
  return Response.json(r, { status: r.ok ? 200 : 400 });
}
