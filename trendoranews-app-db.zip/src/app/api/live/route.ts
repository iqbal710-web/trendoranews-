import type { NextRequest } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { articles } from "@/db/schema";
import { getLiveUpdates } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const id = Number(req.nextUrl.searchParams.get("articleId"));
  if (!id) return Response.json({ updates: [], isLive: false });
  const [a] = await db.select({ isLive: articles.isLive, updatedAt: articles.updatedAt }).from(articles).where(eq(articles.id, id)).limit(1);
  const updates = await getLiveUpdates(id);
  return Response.json({ updates, isLive: !!a?.isLive }, { headers: { "Cache-Control": "no-store" } });
}
