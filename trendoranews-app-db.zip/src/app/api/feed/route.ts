import type { NextRequest } from "next/server";
import { latest } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const g = (k: string) => sp.get(k) || undefined;
  const limit = Math.min(24, Math.max(1, Number(sp.get("limit") || 9)));
  const offset = Math.max(0, Number(sp.get("offset") || 0));
  const items = await latest(limit, offset, {
    category: g("category"), sub: g("sub"), country: g("country"), region: g("region"), tag: g("tag"), author: g("author"), type: g("type"), from: g("from"), to: g("to"),
  });
  return Response.json({ items, done: items.length < limit });
}
