import { breakingNow } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json(await breakingNow(), { headers: { "Cache-Control": "no-store" } });
}
