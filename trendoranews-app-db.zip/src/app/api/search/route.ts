import type { NextRequest } from "next/server";
import { getUser } from "@/lib/auth";
import { logSearch, runSearch, suggest } from "@/lib/search";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const q = sp.get("q") ?? "";
  if (sp.get("mode") === "suggest") return Response.json(await suggest(q));
  const g = (k: string) => sp.get(k) || undefined;
  const res = await runSearch({
    q, category: g("category"), country: g("country"), author: g("author"), tag: g("tag"), type: g("type"),
    from: g("from"), to: g("to"), sort: g("sort"), page: Math.max(1, Number(sp.get("page") || 1)),
  });
  if (sp.get("log") && q.trim()) {
    const u = await getUser();
    await logSearch(q, res.total, u?.id);
  }
  return Response.json(res);
}
