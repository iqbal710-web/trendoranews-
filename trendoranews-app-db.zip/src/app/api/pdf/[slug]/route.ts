import type { NextRequest } from "next/server";
import { getArticleBySlug } from "@/lib/queries";
import { formatDate, parseBody } from "@/lib/utils";

export const dynamic = "force-dynamic";

const clean = (s: string) =>
  s
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201c\u201d]/g, '"')
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/\u2026/g, "...")
    .replace(/[^\x20-\x7e\xa0-\xff]/g, "?")
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)");

function wrap(text: string, max: number) {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    if ((cur + " " + w).trim().length > max) {
      lines.push(cur);
      cur = w;
    } else cur = (cur + " " + w).trim();
  }
  if (cur) lines.push(cur);
  return lines;
}

type Line = { text: string; size: number; bold?: boolean; gap?: number };

function buildPdf(lines: Line[]) {
  const W = 595, H = 842, M = 56;
  const pages: string[] = [];
  let ops: string[] = [];
  let y = H - M;
  const flush = () => {
    pages.push(ops.join("\n"));
    ops = [];
    y = H - M;
  };
  for (const l of lines) {
    const lh = l.size * 1.4;
    if (y - lh - (l.gap ?? 0) < M) flush();
    y -= l.gap ?? 0;
    y -= lh;
    ops.push(`BT /${l.bold ? "F2" : "F1"} ${l.size} Tf ${M} ${y.toFixed(1)} Td (${clean(l.text)}) Tj ET`);
  }
  if (ops.length) flush();
  const objs: string[] = [];
  objs[1] = "<< /Type /Catalog /Pages 2 0 R >>";
  const kids = pages.map((_, i) => `${5 + i * 2} 0 R`).join(" ");
  objs[2] = `<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`;
  objs[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Times-Roman /Encoding /WinAnsiEncoding >>";
  objs[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";
  pages.forEach((content, i) => {
    const p = 5 + i * 2;
    objs[p] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Contents ${p + 1} 0 R /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> >>`;
    objs[p + 1] = `<< /Length ${Buffer.byteLength(content, "latin1")} >>\nstream\n${content}\nendstream`;
  });
  let out = "%PDF-1.4\n";
  const offsets: number[] = [];
  for (let i = 1; i < objs.length; i++) {
    offsets[i] = Buffer.byteLength(out, "latin1");
    out += `${i} 0 obj\n${objs[i]}\nendobj\n`;
  }
  const xref = Buffer.byteLength(out, "latin1");
  out += `xref\n0 ${objs.length}\n0000000000 65535 f \n`;
  for (let i = 1; i < objs.length; i++) out += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  out += `trailer\n<< /Size ${objs.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return Buffer.from(out, "latin1");
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const row = await getArticleBySlug(slug);
  if (!row || !["published", "scheduled"].includes(row.a.status)) return new Response("Not found", { status: 404 });
  const a = row.a;
  const lines: Line[] = [{ text: "TrendoraNews", size: 11, bold: true }];
  wrap(a.title, 52).forEach((t, i) => lines.push({ text: t, size: 20, bold: true, gap: i === 0 ? 14 : 0 }));
  lines.push({ text: `${row.author?.name ?? "TrendoraNews Desk"}  |  ${formatDate(a.publishedAt)}  |  ${a.category}`, size: 9, gap: 8 });
  wrap(a.dek, 80).forEach((t, i) => lines.push({ text: t, size: 12, gap: i === 0 ? 10 : 0 }));
  for (const b of parseBody(a.body)) {
    if (b.t === "h") lines.push({ text: b.text, size: 14, bold: true, gap: 12 });
    else if (b.t === "ul") b.items.forEach((it) => wrap(`- ${it}`, 88).forEach((t) => lines.push({ text: t, size: 11 })));
    else wrap(b.t === "q" ? `"${b.text}"` : b.text, 88).forEach((t, i) => lines.push({ text: t, size: 11, gap: i === 0 ? 8 : 0 }));
  }
  if (a.sources.length) {
    lines.push({ text: "Sources & references", size: 12, bold: true, gap: 14 });
    a.sources.forEach((s) => wrap(`- ${s.title} (${s.url})`, 88).forEach((t) => lines.push({ text: t, size: 9 })));
  }
  lines.push({ text: `Read online: /news/${a.slug}`, size: 9, gap: 14 });
  return new Response(new Uint8Array(buildPdf(lines)), {
    headers: { "Content-Type": "application/pdf", "Content-Disposition": `attachment; filename="${a.slug}.pdf"` },
  });
}
