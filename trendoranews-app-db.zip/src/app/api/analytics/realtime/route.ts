import { canSeeAnalytics, getUser } from "@/lib/auth";
import { realtime } from "@/lib/analytics";

export const dynamic = "force-dynamic";

export async function GET() {
  const u = await getUser();
  if (!u || !canSeeAnalytics(u.role)) return Response.json({ message: "Not allowed" }, { status: 403 });
  return Response.json(await realtime(), { headers: { "Cache-Control": "no-store" } });
}
