import type { NextRequest } from "next/server";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { articles, bookmarks, comments, factChecks, follows, notifications, reactions, readingHistory, users } from "@/db/schema";
import { getUser, hashPassword, isEditor, verifyPassword } from "@/lib/auth";
import { getComments } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const id = Number(req.nextUrl.searchParams.get("articleId"));
  if (!id) return Response.json({ comments: [] });
  const list = await getComments(id);
  return Response.json({ comments: list.map((c) => ({ ...c, createdAt: c.createdAt.toISOString() })) });
}

const bad = (message: string, status = 400) => Response.json({ ok: false, message }, { status });

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => null);
  if (!b?.action) return bad("Missing action");
  const user = await getUser();
  const needUser = () => (user ? null : bad("Please log in to do that.", 401));

  switch (b.action) {
    case "like": {
      const articleId = Number(b.articleId);
      const key = user ? `u:${user.id}` : `a:${String(b.vid || "anon").slice(0, 64)}`;
      const ex = await db.select({ id: reactions.id }).from(reactions).where(and(eq(reactions.articleId, articleId), eq(reactions.userKey, key))).limit(1);
      let liked: boolean;
      if (ex[0]) {
        await db.delete(reactions).where(eq(reactions.id, ex[0].id));
        liked = false;
      } else {
        await db.insert(reactions).values({ articleId, userKey: key });
        liked = true;
      }
      const [row] = await db.update(articles).set({ likes: sql`greatest(0, ${articles.likes} + ${liked ? 1 : -1})` }).where(eq(articles.id, articleId)).returning({ likes: articles.likes });
      return Response.json({ ok: true, liked, likes: row?.likes ?? 0 });
    }
    case "share": {
      const [row] = await db.update(articles).set({ shares: sql`${articles.shares} + 1` }).where(eq(articles.id, Number(b.articleId))).returning({ shares: articles.shares });
      return Response.json({ ok: true, shares: row?.shares ?? 0 });
    }
    case "bookmark": {
      const e = needUser();
      if (e) return e;
      const articleId = Number(b.articleId);
      const ex = await db.select({ id: bookmarks.id }).from(bookmarks).where(and(eq(bookmarks.userId, user!.id), eq(bookmarks.articleId, articleId))).limit(1);
      if (ex[0]) await db.delete(bookmarks).where(eq(bookmarks.id, ex[0].id));
      else await db.insert(bookmarks).values({ userId: user!.id, articleId });
      return Response.json({ ok: true, bookmarked: !ex[0] });
    }
    case "comment": {
      const e = needUser();
      if (e) return e;
      const body = String(b.body || "").trim().slice(0, 2000);
      if (body.length < 2) return bad("Write a comment first.");
      const [c] = await db.insert(comments).values({ articleId: Number(b.articleId), userId: user!.id, body }).returning();
      return Response.json({ ok: true, comment: { id: c.id, body: c.body, createdAt: c.createdAt.toISOString(), userId: user!.id, name: user!.name, role: user!.role, parentId: null } });
    }
    case "deleteComment": {
      const e = needUser();
      if (e) return e;
      const id = Number(b.id);
      const row = await db.select().from(comments).where(eq(comments.id, id)).limit(1);
      if (!row[0] || (row[0].userId !== user!.id && !isEditor(user!.role))) return bad("Not allowed", 403);
      await db.delete(comments).where(eq(comments.id, id));
      return Response.json({ ok: true });
    }
    case "follow": {
      const e = needUser();
      if (e) return e;
      const kind = b.kind === "author" ? "author" : "category";
      const target = String(b.target);
      const ex = await db.select({ id: follows.id }).from(follows).where(and(eq(follows.userId, user!.id), eq(follows.kind, kind), eq(follows.target, target))).limit(1);
      if (ex[0]) await db.delete(follows).where(eq(follows.id, ex[0].id));
      else await db.insert(follows).values({ userId: user!.id, kind, target });
      return Response.json({ ok: true, following: !ex[0] });
    }
    case "prefs": {
      const e = needUser();
      if (e) return e;
      const prefs = { ...(user!.preferences ?? {}), ...(b.prefs ?? {}) };
      await db.update(users).set({ preferences: prefs }).where(eq(users.id, user!.id));
      return Response.json({ ok: true });
    }
    case "notifications": {
      const e = needUser();
      if (e) return e;
      if (b.ids?.length) await db.update(notifications).set({ read: true }).where(and(eq(notifications.userId, user!.id), inArray(notifications.id, b.ids.map(Number))));
      else await db.update(notifications).set({ read: true }).where(eq(notifications.userId, user!.id));
      return Response.json({ ok: true });
    }
    case "clearHistory": {
      const e = needUser();
      if (e) return e;
      await db.delete(readingHistory).where(eq(readingHistory.userId, user!.id));
      return Response.json({ ok: true });
    }
    case "settings": {
      const e = needUser();
      if (e) return e;
      const name = String(b.name || "").trim();
      const patch: Partial<typeof users.$inferInsert> = {};
      if (name.length >= 2) patch.name = name;
      if (b.newPassword) {
        const row = await db.select().from(users).where(eq(users.id, user!.id)).limit(1);
        if (row[0].passwordHash && !verifyPassword(String(b.currentPassword || ""), row[0].passwordHash)) return bad("Current password is incorrect.");
        if (String(b.newPassword).length < 6) return bad("New password must be at least 6 characters.");
        patch.passwordHash = hashPassword(String(b.newPassword));
      }
      if (Object.keys(patch).length) await db.update(users).set(patch).where(eq(users.id, user!.id));
      return Response.json({ ok: true, message: "Settings saved." });
    }
    case "submitClaim": {
      const claim = String(b.claim || "").trim().slice(0, 500);
      if (claim.length < 8) return bad("Please describe the claim in a little more detail.");
      await db.insert(factChecks).values({ claim, verdict: "unproven", explanation: "", status: "submitted", submittedBy: user?.email ?? String(b.email || "anonymous").slice(0, 120) });
      return Response.json({ ok: true, message: "Thanks! Our fact-checkers will review your claim." });
    }
    default:
      return bad("Unknown action");
  }
  void desc;
}
