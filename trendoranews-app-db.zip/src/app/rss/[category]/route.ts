import { latest } from "@/lib/queries";
import { CAT_MAP } from "@/lib/taxonomy";
import { RSS_HEADERS, SITE_NAME, buildRss } from "@/lib/rss";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ category: string }> }) {
  const { category } = await params;
  const slug = category.replace(/\.xml$/, "");
  const c = CAT_MAP[slug];
  if (!c) return new Response("Not found", { status: 404 });
  const items = await latest(40, 0, { category: slug });
  return new Response(buildRss(`${SITE_NAME} — ${c.name}`, `/rss/${slug}`, items, c.blurb), { headers: RSS_HEADERS });
}
