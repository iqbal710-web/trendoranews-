import Link from "next/link";
import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { factChecks } from "@/db/schema";
import { VERDICTS } from "@/lib/taxonomy";
import { formatDate } from "@/lib/utils";
import { PageHero } from "@/components/cards";
import ClaimForm from "@/components/ClaimForm";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Fact Check Center — claims verified", description: "Viral claims, myths and rumours checked against evidence by TrendoraNews fact-checkers. Submit a claim for review.", alternates: { canonical: "/fact-check" } };

export default async function FactCheckPage({ searchParams }: { searchParams: Promise<{ v?: string }> }) {
  const { v } = await searchParams;
  const rows = await db.select().from(factChecks).where(eq(factChecks.status, "published")).orderBy(desc(factChecks.createdAt));
  const shown = v ? rows.filter((r) => r.verdict === v) : rows;
  return (
    <>
      <PageHero kicker="Verification" title="Fact Check Center" sub="We investigate viral claims and common myths, show our evidence, and give a clear verdict.">
        <div className="mt-4 flex flex-wrap gap-2"><Link href="/fact-check" className={`chip ${!v ? "btn-active" : ""}`}>All ({rows.length})</Link>{Object.entries(VERDICTS).map(([k, x]) => <Link key={k} href={`/fact-check?v=${k}`} className={`chip ${v === k ? "btn-active" : ""}`}>{x.label} ({rows.filter((r) => r.verdict === k).length})</Link>)}</div>
      </PageHero>
      <div className="wrap grid gap-8 py-8 lg:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-4">
          {shown.map((r) => (
            <article key={r.id} className="panel">
              <div className="flex flex-wrap items-center gap-3"><span className={`rounded px-2.5 py-1 text-xs font-extrabold uppercase tracking-wider ${VERDICTS[r.verdict]?.tone}`}>{VERDICTS[r.verdict]?.label}</span><span className="text-xs text-muted">{formatDate(r.createdAt)} · checked by {r.checkedBy ?? "TrendoraNews"}</span></div>
              <h2 className="h-serif mt-2 text-xl font-bold leading-snug">“{r.claim}”</h2>
              <p className="mt-2 text-[15px]">{r.explanation}</p>
              {r.sources.length > 0 && <ul className="mt-2 text-xs text-muted">{r.sources.map((s, i) => <li key={i}>Source: <a className="text-brand" href={s.url} target="_blank" rel="noopener noreferrer nofollow">{s.title}</a></li>)}</ul>}
            </article>
          ))}
          {!shown.length && <div className="panel text-muted">No fact-checks with this verdict yet.</div>}
        </div>
        <aside className="space-y-4 lg:sticky lg:top-28 lg:self-start">
          <div className="panel"><div className="kicker text-brand">Submit a claim</div><h2 className="h-serif mb-2 text-xl font-black">Seen something suspicious?</h2><p className="mb-3 text-sm text-muted">Paste a claim, forwarded message or link. Our fact-checkers review submissions daily.</p><ClaimForm /></div>
          <div className="panel text-sm"><h2 className="font-bold">How we rate claims</h2><ul className="mt-2 space-y-1.5">{Object.entries(VERDICTS).map(([k, x]) => <li key={k}><span className={`mr-2 rounded px-1.5 py-0.5 text-[10px] font-bold uppercase ${x.tone}`}>{x.label}</span></li>)}</ul></div>
        </aside>
      </div>
    </>
  );
}
