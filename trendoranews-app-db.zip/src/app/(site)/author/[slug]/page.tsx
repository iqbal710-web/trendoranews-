import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { articles, follows } from "@/db/schema";
import { getUser } from "@/lib/auth";
import { getAuthor, isPublished } from "@/lib/queries";
import { COUNTRY_MAP } from "@/lib/reference";
import { SITE_URL, compact, flag } from "@/lib/utils";
import Listing from "@/components/Listing";
import JsonLd from "@/components/JsonLd";
import { FollowButton } from "@/components/Engagement";
import { VerifiedBadge } from "@/components/cards";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const a = await getAuthor(slug);
  return a ? { title: `${a.name} — ${a.title}`, description: a.bio ?? undefined, alternates: { canonical: `/author/${slug}` }, openGraph: { type: "profile", title: a.name } } : { title: "Author not found" };
}

export default async function AuthorPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const a = await getAuthor(slug);
  if (!a) notFound();
  const user = await getUser();
  const [stats] = await db.select({ n: sql<number>`count(*)::int`, v: sql<number>`coalesce(sum(${articles.views}),0)::int` }).from(articles).where(and(isPublished(), eq(articles.authorId, a.id)));
  const following = user ? (await db.select({ id: follows.id }).from(follows).where(and(eq(follows.userId, user.id), eq(follows.kind, "author"), eq(follows.target, slug))).limit(1)).length > 0 : false;
  return (
    <>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "ProfilePage", mainEntity: { "@type": "Person", name: a.name, jobTitle: a.title, description: a.bio, url: `${SITE_URL}/author/${a.slug}`, worksFor: { "@type": "NewsMediaOrganization", name: "TrendoraNews" } } }} />
      <Listing
        kicker={a.kind === "columnist" ? "Columnist" : "Author profile"}
        title={a.name}
        sub={a.title ?? undefined}
        filters={{ author: slug }}
        hero={
          <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-start">
            <span className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full bg-brand/15 text-3xl font-black text-brand">{a.name[0]}</span>
            <div className="max-w-2xl">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                {a.verified && <span className="inline-flex items-center gap-1 rounded-full bg-sky-500/15 px-2.5 py-1 text-xs font-bold text-sky-700 dark:text-sky-300"><VerifiedBadge /> Verified journalist</span>}
                {a.country && <span className="text-muted">{flag(a.country)} {COUNTRY_MAP[a.country]?.name}</span>}
                {a.twitter && <span className="text-muted">{a.twitter}</span>}
              </div>
              <h2 className="sr-only">Biography</h2>
              <p className="mt-2">{a.bio}</p>
              <div className="mt-3 flex flex-wrap items-center gap-3 text-sm"><b>{stats?.n ?? 0}</b> stories <b>{compact(stats?.v ?? 0)}</b> reads <FollowButton kind="author" target={slug} initial={following} loggedIn={!!user} label="Follow author" /></div>
            </div>
          </div>
        }
      />
    </>
  );
}
