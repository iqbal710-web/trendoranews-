import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { archiveMonths } from "@/lib/queries";
import Listing from "@/components/Listing";
import { PageHero } from "@/components/cards";

export const dynamic = "force-dynamic";

const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

export async function generateMetadata({ params }: { params: Promise<{ date?: string[] }> }): Promise<Metadata> {
  const { date } = await params;
  const t = date?.length ? `Archive: ${date.length > 1 ? `${MONTHS[Number(date[1]) - 1] ?? ""} ` : ""}${date[0]}` : "News archive";
  return { title: t, description: "Browse every TrendoraNews story by year and month.", alternates: { canonical: `/archive${date?.length ? `/${date.join("/")}` : ""}` } };
}

export default async function ArchivePage({ params }: { params: Promise<{ date?: string[] }> }) {
  const { date } = await params;
  const [y, m] = date ?? [];
  if (y && m) {
    const mi = Number(m);
    if (!/^\d{4}$/.test(y) || mi < 1 || mi > 12) notFound();
    const last = new Date(Date.UTC(Number(y), mi, 0)).getUTCDate();
    return <Listing kicker="Archive" title={`${MONTHS[mi - 1]} ${y}`} sub="Every story published this month." filters={{ from: `${y}-${m.padStart(2, "0")}-01`, to: `${y}-${m.padStart(2, "0")}-${last}` }} hero={<Link href="/archive" className="mt-3 inline-block text-sm text-brand">← All months</Link>} />;
  }
  const rows = await archiveMonths();
  const years = [...new Set(rows.map((r) => r.y))].filter((yy) => !y || yy === y);
  if (y && !years.length) notFound();
  return (
    <>
      <PageHero kicker="Archive" title={y ? `Archive ${y}` : "News archive"} sub="Browse every published story by year and month." />
      <div className="wrap py-8 space-y-8">
        {years.map((yy) => (
          <section key={yy}>
            <h2 className="h-serif mb-3 text-2xl font-black"><Link href={`/archive/${yy}`} className="hover:text-brand">{yy}</Link></h2>
            <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
              {rows.filter((r) => r.y === yy).map((r) => (
                <Link key={r.m} href={`/archive/${yy}/${r.m}`} className="panel !p-4 transition hover:border-brand"><div className="font-bold">{MONTHS[Number(r.m) - 1]}</div><div className="text-xs text-muted">{r.c} stories</div></Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </>
  );
}
