import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { and, desc, eq, inArray, or } from "drizzle-orm";
import { db } from "@/db";
import { articles, liveUpdates } from "@/db/schema";
import { isPublished } from "@/lib/queries";
import { formatDate } from "@/lib/utils";
import { PageHero } from "@/components/cards";
import { AnimalExplorer, HistoryTimeline, SpaceExplorer } from "@/components/explore/Explorers1";
import { Compare, DataViz, Explainers, GeographyExplorer } from "@/components/explore/Explorers2";

export const dynamic = "force-dynamic";

const META: Record<string, { title: string; kicker: string; sub: string }> = {
  history: { title: "Historical Timeline", kicker: "History explorer", sub: "Travel from ancient civilisations to the modern world. Filter by era, search events and open related coverage." },
  geography: { title: "Country Explorer", kicker: "Geography explorer", sub: "Browse countries, compare size and population, and explore the world's great mountains and oceans." },
  animals: { title: "Animal Encyclopedia", kicker: "Animals explorer", sub: "Wildlife, pets and marine life — habitat, diet, lifespan and conservation status." },
  space: { title: "Space Explorer", kicker: "Science", sub: "An animated model of the solar system, plus the missions and telescopes that opened the cosmos." },
  data: { title: "Data Visualization", kicker: "Charts & graphs", sub: "Interactive charts built from open data. Hover for details, switch to a table, or download the CSV." },
  compare: { title: "News Comparison", kicker: "Side by side", sub: "Compare two events across the same set of facts to see what really differs." },
  events: { title: "Event Timeline", kicker: "Developing stories", sub: "Follow the sequence of events for live and developing stories — every update, in order." },
  explainers: { title: "Explainer Center", kicker: "Made simple", sub: "Complex topics explained simply — then go deeper if you want to." },
};

export async function generateMetadata({ params }: { params: Promise<{ tool: string }> }): Promise<Metadata> {
  const { tool } = await params;
  const m = META[tool];
  return m ? { title: m.title, description: m.sub, alternates: { canonical: `/explore/${tool}` } } : { title: "Not found" };
}

export default async function ToolPage({ params, searchParams }: { params: Promise<{ tool: string }>; searchParams: Promise<{ c?: string }> }) {
  const { tool } = await params;
  const { c } = await searchParams;
  const m = META[tool];
  if (!m) notFound();

  let body;
  switch (tool) {
    case "history": body = <HistoryTimeline />; break;
    case "geography": body = <GeographyExplorer initial={c} />; break;
    case "animals": body = <AnimalExplorer />; break;
    case "space": body = <SpaceExplorer />; break;
    case "data": body = <DataViz />; break;
    case "compare": body = <Compare />; break;
    case "explainers": body = <Explainers />; break;
    default: {
      const stories = await db.select().from(articles).where(and(or(eq(articles.isDeveloping, true), eq(articles.isLive, true), eq(articles.type, "live")), isPublished())).orderBy(desc(articles.updatedAt)).limit(6);
      const ups = stories.length ? await db.select().from(liveUpdates).where(inArray(liveUpdates.articleId, stories.map((s) => s.id))).orderBy(desc(liveUpdates.createdAt)) : [];
      body = (
        <div className="grid gap-8 lg:grid-cols-2">
          {stories.map((s) => {
            const mine = ups.filter((u) => u.articleId === s.id).reverse();
            const steps = [{ t: s.publishedAt ?? s.createdAt, title: "Story first published", body: s.dek, kind: "start" }, ...mine.map((u) => ({ t: u.createdAt, title: u.title, body: u.body, kind: u.kind })), ...s.corrections.map((c2) => ({ t: new Date(c2.date), title: "Correction", body: c2.note, kind: "correction" })), ...(s.updatedAt.getTime() - (s.publishedAt ?? s.createdAt).getTime() > 600000 ? [{ t: s.updatedAt, title: "Last updated", body: "", kind: "update" }] : [])].sort((a, b) => +a.t - +b.t);
            return (
              <article key={s.id} className="panel">
                <div className="flex items-center gap-2">{s.isLive && <span className="inline-flex items-center gap-1 rounded bg-brand px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-white"><span className="live-dot !h-1.5 !w-1.5 !bg-white" /> Live</span>}{s.isDeveloping && <span className="rounded bg-amber-500 px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-black">Developing</span>}</div>
                <h2 className="h-serif mt-2 text-xl font-black"><Link href={`/news/${s.slug}`} className="hover:text-brand">{s.title}</Link></h2>
                <ol className="relative mt-4 space-y-4 border-l-2 border-line pl-5 text-sm">
                  {steps.map((st, i) => <li key={i} className="relative"><span className={`absolute -left-[27px] top-1 h-3 w-3 rounded-full ${st.kind === "alert" ? "bg-brand" : st.kind === "correction" ? "bg-amber-500" : st.kind === "start" ? "bg-emerald-500" : "bg-sky-500"}`} /><div className="text-xs text-muted">{formatDate(st.t, true)}</div><div className="font-semibold">{st.title}</div>{st.body && <p className="line-clamp-2 text-muted">{st.body}</p>}</li>)}
                </ol>
              </article>
            );
          })}
          {!stories.length && <p className="text-muted">No developing stories right now.</p>}
        </div>
      );
    }
  }
  return (
    <>
      <PageHero kicker={m.kicker} title={m.title} sub={m.sub}><div className="mt-3"><Link href="/explore" className="text-sm text-brand">← All explorers</Link></div></PageHero>
      <div className="wrap py-8">{body}</div>
    </>
  );
}
