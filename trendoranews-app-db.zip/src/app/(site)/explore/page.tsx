import Link from "next/link";
import type { Metadata } from "next";
import { PageHero } from "@/components/cards";

export const metadata: Metadata = { title: "Explore & Learn — interactive explorers", description: "Interactive world map, historical timeline, country explorer, animal encyclopedia, space explorer, data visualisation, news comparison and more.", alternates: { canonical: "/explore" } };

const TOOLS: [string, string, string, string][] = [
  ["/world", "🌐", "Interactive World Map", "News on a world map — click a country for stories and facts."],
  ["/explore/history", "🏛️", "Historical Timeline", "From ancient civilisations to the modern era, event by event."],
  ["/explore/geography", "🗺️", "Country Explorer", "Compare countries, mountains and oceans in one place."],
  ["/explore/animals", "🐅", "Animal Encyclopedia", "Wildlife, pets and marine life with conservation status."],
  ["/explore/space", "🚀", "Space Explorer", "An animated solar system plus missions and telescopes."],
  ["/explore/data", "📊", "Data Visualization", "Charts and graphs that make numbers easy to read."],
  ["/explore/compare", "⚖️", "News Comparison", "Put two events side by side and see what's different."],
  ["/explore/events", "🧭", "Event Timeline", "Follow developing stories step by step."],
  ["/fact-check", "✅", "Fact Check Center", "Rumours and myths checked against the evidence."],
  ["/explore/explainers", "💡", "Explainer Center", "Complicated topics made simple — or go deeper."],
];

export default function ExplorePage() {
  return (
    <>
      <PageHero kicker="Interactive" title="Explore & learn" sub="Interactive explorers that turn the news into something you can touch. Special explorers for History, Animals and Geography." />
      <div className="wrap grid gap-4 py-10 sm:grid-cols-2 lg:grid-cols-3">
        {TOOLS.map(([h, e, t, d]) => (
          <Link key={h} href={h} className="group panel flex gap-4 transition hover:-translate-y-0.5 hover:border-brand hover:shadow-lg">
            <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-brand/10 text-3xl">{e}</span>
            <span><span className="block text-lg font-bold group-hover:text-brand">{t}</span><span className="text-sm text-muted">{d}</span></span>
          </Link>
        ))}
      </div>
    </>
  );
}
