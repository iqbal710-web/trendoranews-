import Link from "next/link";
import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { authors, galleries } from "@/db/schema";
import { PageHero, SectionHeader, VerifiedBadge } from "@/components/cards";
import Img from "@/components/Img";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Photography — galleries, photo stories & archive", description: "Photo galleries, photo stories, before & after comparisons and a historical photo archive.", alternates: { canonical: "/photos" } };

const KINDS: [string, string][] = [["", "All"], ["gallery", "Galleries"], ["photo_story", "Photo stories"], ["before_after", "Before & After"], ["archive", "Historical archive"]];

export default async function PhotosPage({ searchParams }: { searchParams: Promise<{ kind?: string }> }) {
  const { kind } = await searchParams;
  const rows = await db.select({ g: galleries, p: authors }).from(galleries).leftJoin(authors, eq(authors.id, galleries.photographerId)).where(kind ? eq(galleries.kind, kind) : undefined).orderBy(desc(galleries.publishedAt));
  const photographers = await db.select().from(authors).where(eq(authors.kind, "photographer"));
  return (
    <>
      <PageHero kicker="Photography" title="Photo galleries" sub="Galleries, photo stories, slideshows, before & after comparisons and the historical photo archive.">
        <div className="mt-4 flex flex-wrap gap-2">{KINDS.map(([k, l]) => <Link key={k} href={k ? `/photos?kind=${k}` : "/photos"} className={`chip ${(kind ?? "") === k ? "btn-active" : ""}`}>{l}</Link>)}</div>
      </PageHero>
      <div className="wrap space-y-12 py-8">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map(({ g, p }) => (
            <Link key={g.id} href={`/photos/${g.slug}`} className="group overflow-hidden rounded-2xl border border-line bg-card transition hover:shadow-lg">
              <div className="relative aspect-[4/3] overflow-hidden"><Img src={g.coverImage} alt={g.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" /><span className="absolute left-3 top-3 rounded bg-black/70 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white">{g.kind.replace("_", " ")}</span><span className="absolute bottom-3 right-3 rounded bg-black/70 px-2 py-0.5 text-xs text-white">📷 {g.images.length}</span></div>
              <div className="p-4"><h2 className="h-serif text-lg font-bold leading-snug">{g.title}</h2><p className="mt-1 line-clamp-2 text-sm text-muted">{g.description}</p><div className="mt-2 text-xs text-muted">{p?.name}{g.location ? ` · ${g.location}` : ""}{g.era ? ` · ${g.era}` : ""}</div></div>
            </Link>
          ))}
          {!rows.length && <div className="panel col-span-full text-muted">Nothing here yet.</div>}
        </div>
        <section>
          <SectionHeader title="Photographers" kicker="Behind the lens" />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {photographers.map((p) => (
              <Link key={p.id} href={`/photographers/${p.slug}`} className="panel flex gap-4 transition hover:border-brand">
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-brand/15 text-xl font-black text-brand">{p.name[0]}</span>
                <div><div className="flex items-center gap-1 font-bold">{p.name}{p.verified && <VerifiedBadge />}</div><div className="text-xs text-muted">{p.title}</div><p className="mt-1 line-clamp-2 text-sm text-muted">{p.bio}</p></div>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </>
  );
}
