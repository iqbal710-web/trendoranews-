import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { authors, galleries } from "@/db/schema";
import { SITE_URL, formatDate } from "@/lib/utils";
import GalleryView from "@/components/GalleryView";
import JsonLd from "@/components/JsonLd";
import { PageHero, VerifiedBadge } from "@/components/cards";

export const dynamic = "force-dynamic";

async function load(slug: string) {
  const [r] = await db.select({ g: galleries, p: authors }).from(galleries).leftJoin(authors, eq(authors.id, galleries.photographerId)).where(eq(galleries.slug, slug)).limit(1);
  return r ?? null;
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const r = await load(slug);
  if (!r) return { title: "Gallery not found" };
  return { title: r.g.title, description: r.g.description, alternates: { canonical: `/photos/${slug}` }, openGraph: { title: r.g.title, description: r.g.description, images: r.g.coverImage ? [r.g.coverImage] : [] } };
}

export default async function GalleryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const r = await load(slug);
  if (!r) notFound();
  const { g, p } = r;
  await db.update(galleries).set({ views: sql`${galleries.views} + 1` }).where(eq(galleries.id, g.id));
  return (
    <>
      <JsonLd data={{ "@context": "https://schema.org", "@type": "ImageGallery", name: g.title, description: g.description, datePublished: g.publishedAt.toISOString(), author: p ? { "@type": "Person", name: p.name, url: `${SITE_URL}/photographers/${p.slug}` } : undefined, image: g.images.map((i) => ({ "@type": "ImageObject", contentUrl: i.url, caption: i.caption, name: i.alt })) }} />
      <PageHero kicker={g.kind.replace("_", " ")} title={g.title} sub={g.description}>
        <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-muted">
          {p && <Link href={`/photographers/${p.slug}`} className="inline-flex items-center gap-1 font-semibold text-ink hover:text-brand">📷 {p.name}{p.verified && <VerifiedBadge />}</Link>}
          {g.location && <span>📍 {g.location}</span>}{g.era && <span>🕰 {g.era}</span>}<span>{formatDate(g.publishedAt)}</span><span>{g.images.length} photos</span>
        </div>
      </PageHero>
      <div className="wrap py-8"><GalleryView kind={g.kind} images={g.images} /></div>
    </>
  );
}
