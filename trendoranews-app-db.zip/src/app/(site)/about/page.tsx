import type { Metadata } from "next";
import { PageHero } from "@/components/cards";
import NewsletterForm from "@/components/NewsletterForm";

export const metadata: Metadata = { title: "About TrendoraNews & editorial standards", description: "Our mission, editorial standards, corrections policy and how we verify the news.", alternates: { canonical: "/about" } };

export default function AboutPage() {
  const items = [
    ["Accuracy first", "Every story is reviewed by an editor. Claims that can be checked are checked, and our fact-check status badge shows where each story stands."],
    ["Transparent corrections", "When we get something wrong we say so — prominently, with a dated note on the article and a permanent revision history."],
    ["Verified journalists", "A blue tick on an author profile means we have confirmed their identity and track record."],
    ["Clear labelling", "Opinion, analysis, live coverage, investigations and fact-checks are always labelled so you know what you're reading."],
    ["Live & developing news", "Breaking labels expire automatically. Live pages keep a full, timestamped history, including corrections."],
    ["Independence", "Editorial decisions are made by editors, not advertisers. Newsletter and account data is never sold."],
  ];
  return (
    <>
      <PageHero kicker="About" title="Trending. Trusted. Told first." sub="TrendoraNews is a demonstration newsroom platform built around speed, verification and reader trust. All stories and people shown in this demo are illustrative." />
      <div className="wrap grid gap-5 py-10 md:grid-cols-2 lg:grid-cols-3">
        {items.map(([t, d]) => <div key={t} className="panel"><h2 className="h-serif text-xl font-black">{t}</h2><p className="mt-1 text-sm text-muted">{d}</p></div>)}
      </div>
      <div className="wrap pb-12"><div className="panel max-w-xl"><h2 className="h-serif mb-2 text-xl font-black">Stay in touch</h2><NewsletterForm /></div></div>
    </>
  );
}
