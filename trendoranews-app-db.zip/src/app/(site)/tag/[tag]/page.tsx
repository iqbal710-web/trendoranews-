import type { Metadata } from "next";
import Listing from "@/components/Listing";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ tag: string }> }): Promise<Metadata> {
  const { tag } = await params;
  const t = decodeURIComponent(tag);
  return { title: `#${t} — stories and updates`, description: `All TrendoraNews coverage tagged ${t}.`, alternates: { canonical: `/tag/${encodeURIComponent(t)}` } };
}

export default async function TagPage({ params }: { params: Promise<{ tag: string }> }) {
  const { tag } = await params;
  const t = decodeURIComponent(tag);
  return <Listing kicker="Topic" title={`#${t}`} sub={`Everything we've published about “${t}”.`} filters={{ tag: t }} />;
}
