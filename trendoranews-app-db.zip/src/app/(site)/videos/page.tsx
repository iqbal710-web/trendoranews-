import Link from "next/link";
import type { Metadata } from "next";
import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { playlists, videos } from "@/db/schema";
import { VIDEO_CATEGORIES } from "@/lib/taxonomy";
import { compact, timeAgo } from "@/lib/utils";
import { PageHero, SectionHeader } from "@/components/cards";
import Img from "@/components/Img";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Videos — news, explainers, documentaries", description: "Watch trending and featured videos from TrendoraNews, with chapters, subtitles and transcripts.", alternates: { canonical: "/videos" } };

type V = typeof videos.$inferSelect;
function VCard({ v }: { v: V }) {
  return (
    <Link href={`/videos/${v.slug}`} className="group overflow-hidden rounded-xl border border-line bg-card transition hover:shadow-lg">
      <div className="relative aspect-video overflow-hidden"><Img src={v.poster} alt={v.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" /><span className="absolute inset-0 flex items-center justify-center"><span className="flex h-12 w-12 items-center justify-center rounded-full bg-black/60 text-xl text-white">▶</span></span><span className="absolute bottom-2 right-2 rounded bg-black/80 px-1.5 py-0.5 text-[11px] font-semibold text-white">{Math.floor(v.durationSec / 60)}:{String(v.durationSec % 60).padStart(2, "0")}</span></div>
      <div className="p-3"><div className="kicker text-brand">{v.category}</div><h3 className="mt-0.5 line-clamp-2 font-bold leading-snug">{v.title}</h3><div className="mt-1 text-xs text-muted">{compact(v.views)} views · {timeAgo(v.publishedAt)}</div></div>
    </Link>
  );
}

export default async function VideosPage({ searchParams }: { searchParams: Promise<{ cat?: string }> }) {
  const { cat } = await searchParams;
  const all = await db.select().from(videos).where(cat ? eq(videos.category, cat) : undefined).orderBy(desc(videos.publishedAt));
  const trending = [...all].sort((a, b) => b.views - a.views).slice(0, 4);
  const featured = all.filter((v) => v.featured);
  const lists = await db.select().from(playlists).orderBy(asc(playlists.id));
  const hero = featured[0] ?? all[0];
  return (
    <>
      <PageHero kicker="TrendoraNews Video" title="Videos" sub="Video news, explainers and short films — with chapters, subtitles, transcripts and picture-in-picture.">
        <div className="mt-4 flex flex-wrap gap-2">
          <Link href="/videos" className={`chip ${!cat ? "btn-active" : ""}`}>All</Link>
          {VIDEO_CATEGORIES.map((c) => <Link key={c} href={`/videos?cat=${encodeURIComponent(c)}`} className={`chip ${cat === c ? "btn-active" : ""}`}>{c}</Link>)}
        </div>
      </PageHero>
      <div className="wrap space-y-12 py-8">
        {hero && (
          <Link href={`/videos/${hero.slug}`} className="group relative block overflow-hidden rounded-2xl">
            <div className="aspect-[21/9]"><Img src={hero.poster} alt={hero.title} eager className="h-full w-full object-cover transition duration-700 group-hover:scale-105" /></div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
            <span className="absolute left-1/2 top-1/2 flex h-16 w-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-brand text-2xl text-white shadow-xl">▶</span>
            <div className="absolute inset-x-0 bottom-0 p-6 text-white"><div className="kicker text-white/80">Featured video · {hero.category}</div><h2 className="h-serif text-2xl font-black sm:text-4xl">{hero.title}</h2><p className="mt-1 line-clamp-1 text-white/80">{hero.description}</p></div>
          </Link>
        )}
        <section><SectionHeader title="🔥 Trending Videos" kicker="Most watched" /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{trending.map((v) => <VCard key={v.id} v={v} />)}</div></section>
        {featured.length > 0 && <section><SectionHeader title="Featured Videos" kicker="Editors' picks" /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{featured.map((v) => <VCard key={v.id} v={v} />)}</div></section>}
        {lists.map((p) => {
          const items = all.filter((v) => v.playlistId === p.id).sort((a, b) => a.playlistOrder - b.playlistOrder);
          if (!items.length) return null;
          return (
            <section key={p.id}>
              <SectionHeader title={`Playlist: ${p.title}`} kicker={`${items.length} videos`} right={<Link href={`/videos/${items[0].slug}`} className="btn btn-sm btn-primary">▶ Play all</Link>} />
              <p className="-mt-2 mb-4 text-sm text-muted">{p.description}</p>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{items.map((v) => <VCard key={v.id} v={v} />)}</div>
            </section>
          );
        })}
        <section><SectionHeader title="All videos" /><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{all.map((v) => <VCard key={v.id} v={v} />)}</div></section>
      </div>
    </>
  );
}
