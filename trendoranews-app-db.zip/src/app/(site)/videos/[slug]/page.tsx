import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { and, asc, eq, ne } from "drizzle-orm";
import { db } from "@/db";
import { playlists, videos } from "@/db/schema";
import { SITE_URL, compact, formatDate } from "@/lib/utils";
import VideoPlayer from "@/components/VideoPlayer";
import JsonLd from "@/components/JsonLd";
import Img from "@/components/Img";

export const dynamic = "force-dynamic";

async function load(slug: string) {
  const [v] = await db.select().from(videos).where(eq(videos.slug, slug)).limit(1);
  return v ?? null;
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const v = await load(slug);
  if (!v) return { title: "Video not found" };
  return { title: v.title, description: v.description, alternates: { canonical: `/videos/${v.slug}` }, openGraph: { type: "video.other", title: v.title, description: v.description, images: v.poster ? [v.poster] : [] }, twitter: { card: "player", title: v.title } };
}

export default async function VideoPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const v = await load(slug);
  if (!v) notFound();
  const list = v.playlistId ? await db.select().from(videos).where(eq(videos.playlistId, v.playlistId)).orderBy(asc(videos.playlistOrder)) : [];
  const [pl] = v.playlistId ? await db.select().from(playlists).where(eq(playlists.id, v.playlistId)).limit(1) : [];
  const idx = list.findIndex((x) => x.id === v.id);
  const next = idx >= 0 ? list[idx + 1] : undefined;
  const related = await db.select().from(videos).where(and(eq(videos.category, v.category), ne(videos.id, v.id))).limit(4);
  const duration = `PT${Math.floor(v.durationSec / 60)}M${v.durationSec % 60}S`;
  return (
    <div className="wrap py-6">
      <JsonLd data={{ "@context": "https://schema.org", "@type": "VideoObject", name: v.title, description: v.description, thumbnailUrl: v.poster, uploadDate: v.publishedAt.toISOString(), contentUrl: v.url, duration, transcript: v.cues.map((c) => c.text).join(" "), publisher: { "@type": "Organization", name: "TrendoraNews", url: SITE_URL } }} />
      <nav className="mb-3 text-xs text-muted"><Link href="/videos" className="hover:text-brand">Videos</Link> › {v.category}</nav>
      <VideoPlayer video={{ id: v.id, slug: v.slug, title: v.title, url: v.url, poster: v.poster, chapters: v.chapters, cues: v.cues }} nextHref={next ? `/videos/${next.slug}` : undefined} />
      <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,1fr)_340px]">
        <div>
          <div className="kicker text-brand">{v.category}</div>
          <h1 className="h-serif mt-1 text-3xl font-black">{v.title}</h1>
          <p className="mt-1 text-sm text-muted">{compact(v.views)} views · {formatDate(v.publishedAt)}</p>
          <p className="mt-4 max-w-2xl">{v.description}</p>
          <div className="mt-4 flex flex-wrap gap-2">{v.tags.map((t) => <Link key={t} href={`/tag/${encodeURIComponent(t)}`} className="chip">#{t}</Link>)}</div>
          {next && <Link href={`/videos/${next.slug}`} className="btn btn-primary mt-5">Up next: {next.title} →</Link>}
        </div>
        <aside className="space-y-6">
          {pl && (
            <div className="panel !p-0">
              <div className="border-b border-line px-4 py-3"><div className="kicker text-brand">Playlist</div><div className="font-bold">{pl.title}</div><div className="text-xs text-muted">{idx + 1} of {list.length}</div></div>
              <ol>{list.map((x, i) => (
                <li key={x.id}><Link href={`/videos/${x.slug}`} className={`flex items-center gap-3 px-3 py-2 hover:bg-soft ${x.id === v.id ? "bg-brand/10" : ""}`}><span className="w-5 text-center text-xs text-muted">{x.id === v.id ? "▶" : i + 1}</span><div className="h-10 w-16 shrink-0 overflow-hidden rounded"><Img src={x.poster} alt="" className="h-full w-full object-cover" /></div><span className="line-clamp-2 text-sm font-semibold">{x.title}</span></Link></li>
              ))}</ol>
            </div>
          )}
          {related.length > 0 && (
            <div><h2 className="mb-2 font-bold">More in {v.category}</h2><div className="space-y-3">{related.map((x) => <Link key={x.id} href={`/videos/${x.slug}`} className="flex gap-3"><div className="h-16 w-28 shrink-0 overflow-hidden rounded-lg"><Img src={x.poster} alt="" className="h-full w-full object-cover" /></div><span className="line-clamp-3 text-sm font-semibold hover:text-brand">{x.title}</span></Link>)}</div></div>
          )}
        </aside>
      </div>
    </div>
  );
}
