import Link from "next/link";
import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { and, count, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { articles, bookmarks, comments, follows, notifications, readingHistory, searchLogs, subscribers } from "@/db/schema";
import { getUser } from "@/lib/auth";
import { getAuthors, getCardsByIds, latest, recommendedFor } from "@/lib/queries";
import { CATEGORIES, ROLE_LABEL } from "@/lib/taxonomy";
import { formatDate, timeAgo } from "@/lib/utils";
import { PageHero, StoryGrid } from "@/components/cards";
import { FollowButton } from "@/components/Engagement";
import { ActionButton, NewsletterToggle, PrefsForm, SettingsForm } from "@/components/DashboardClient";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "My dashboard", robots: { index: false } };

const TABS: [string, string][] = [["overview", "🏠 Overview"], ["feed", "📰 My feed"], ["saved", "🔖 Saved"], ["history", "🕘 History"], ["following", "➕ Following"], ["notifications", "🔔 Notifications"], ["comments", "💬 Comments"], ["newsletter", "✉️ Newsletter"], ["preferences", "🎛 Reading prefs"], ["settings", "⚙️ Settings"]];

export default async function Dashboard({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const { tab = "overview" } = await searchParams;
  const user = await getUser();
  if (!user) redirect("/login?next=/dashboard");

  const [saved, hist, fol, nots, myComments, sub] = await Promise.all([
    db.select({ id: bookmarks.articleId, at: bookmarks.createdAt }).from(bookmarks).where(eq(bookmarks.userId, user.id)).orderBy(desc(bookmarks.createdAt)),
    db.select().from(readingHistory).where(eq(readingHistory.userId, user.id)).orderBy(desc(readingHistory.viewedAt)),
    db.select().from(follows).where(eq(follows.userId, user.id)),
    db.select().from(notifications).where(eq(notifications.userId, user.id)).orderBy(desc(notifications.createdAt)).limit(50),
    db.select({ id: comments.id, body: comments.body, at: comments.createdAt, title: articles.title, slug: articles.slug }).from(comments).innerJoin(articles, eq(articles.id, comments.articleId)).where(eq(comments.userId, user.id)).orderBy(desc(comments.createdAt)),
    db.select({ id: subscribers.id }).from(subscribers).where(eq(subscribers.email, user.email)).limit(1),
  ]);
  const followCats = fol.filter((f) => f.kind === "category").map((f) => f.target);
  const followAuthors = fol.filter((f) => f.kind === "author").map((f) => f.target);
  const unread = nots.filter((n) => !n.read).length;

  let content;
  if (tab === "overview") {
    const rec = await recommendedFor(user, 3);
    const recent = await getCardsByIds(hist.slice(0, 3).map((h) => h.articleId));
    content = (
      <div className="space-y-8">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {[["Saved", saved.length, "saved"], ["Read", hist.length, "history"], ["Following", fol.length, "following"], ["Comments", myComments.length, "comments"], ["Unread alerts", unread, "notifications"]].map(([l, n, t]) => <Link key={l as string} href={`/dashboard?tab=${t}`} className="panel text-center transition hover:border-brand"><div className="h-serif text-3xl font-black text-brand">{n}</div><div className="text-sm text-muted">{l}</div></Link>)}
        </div>
        {recent.length > 0 && <section><h2 className="h-serif mb-3 text-xl font-black">Recently viewed</h2><StoryGrid items={recent} /></section>}
        <section><h2 className="h-serif mb-3 text-xl font-black">Picked for you</h2><StoryGrid items={rec} /></section>
      </div>
    );
  } else if (tab === "feed") {
    const [fromFollowed, rec] = await Promise.all([
      followCats.length ? Promise.all(followCats.map((c) => latest(3, 0, { category: c }))).then((x) => x.flat()) : Promise.resolve([]),
      recommendedFor(user, 6),
    ]);
    const authorStories = followAuthors.length ? (await Promise.all(followAuthors.map((a) => latest(3, 0, { author: a })))).flat() : [];
    const feed = [...new Map([...authorStories, ...fromFollowed].sort((a, b) => +new Date(b.publishedAt) - +new Date(a.publishedAt)).map((c) => [c.id, c])).values()];
    content = (
      <div className="space-y-8">
        <section><h2 className="h-serif mb-1 text-xl font-black">From what you follow</h2><p className="mb-3 text-sm text-muted">{followCats.length + followAuthors.length ? `Following ${followCats.length} categories and ${followAuthors.length} authors.` : "You aren't following anything yet."} <Link href="/dashboard?tab=following" className="text-brand">Manage →</Link></p>{feed.length ? <StoryGrid items={feed.slice(0, 9)} /> : <div className="panel text-muted">Follow categories and authors to build your feed.</div>}</section>
        <section><h2 className="h-serif mb-3 text-xl font-black">Recommended</h2><StoryGrid items={rec} /></section>
      </div>
    );
  } else if (tab === "saved") {
    const cards = await getCardsByIds(saved.map((s) => s.id));
    content = cards.length ? (
      <div className="space-y-3">{cards.map((c) => <div key={c.id} className="panel flex items-center justify-between gap-4"><div><Link href={`/news/${c.slug}`} className="h-serif font-bold hover:text-brand">{c.title}</Link><div className="text-xs text-muted">Saved {timeAgo(saved.find((s) => s.id === c.id)?.at)} · {c.readingMinutes} min read</div></div><ActionButton label="Remove" body={{ action: "bookmark", articleId: c.id }} /></div>)}</div>
    ) : <div className="panel text-muted">No saved articles yet. Tap “Save” on any story.</div>;
  } else if (tab === "history") {
    const cards = await getCardsByIds(hist.map((h) => h.articleId));
    const searches = await db.select().from(searchLogs).where(eq(searchLogs.userId, user.id)).orderBy(desc(searchLogs.createdAt)).limit(10);
    content = (
      <div className="space-y-8">
        <section>
          <div className="mb-3 flex items-center justify-between"><h2 className="h-serif text-xl font-black">Reading history</h2>{hist.length > 0 && <ActionButton label="Clear history" body={{ action: "clearHistory" }} confirm="Clear your whole reading history?" />}</div>
          <div className="space-y-3">{cards.map((c) => { const h = hist.find((x) => x.articleId === c.id)!; return <div key={c.id} className="panel"><div className="flex items-center justify-between gap-4"><Link href={`/news/${c.slug}`} className="h-serif font-bold hover:text-brand">{c.title}</Link><span className="shrink-0 text-xs text-muted">{timeAgo(h.viewedAt)}</span></div><div className="mt-2 flex items-center gap-3"><div className="h-1.5 flex-1 rounded-full bg-soft"><div className="h-full rounded-full bg-brand" style={{ width: `${h.progress}%` }} /></div><span className="text-xs text-muted">{h.progress}% read</span></div></div>; })}{!cards.length && <div className="panel text-muted">Nothing here yet. Articles you read appear here automatically.</div>}</div>
        </section>
        {searches.length > 0 && <section><h2 className="h-serif mb-3 text-xl font-black">Search history</h2><div className="flex flex-wrap gap-2">{searches.map((s) => <Link key={s.id} href={`/search?q=${encodeURIComponent(s.query)}`} className="chip">🔎 {s.query}</Link>)}</div></section>}
      </div>
    );
  } else if (tab === "following") {
    const authors = await getAuthors("journalist");
    content = (
      <div className="space-y-8">
        <section><h2 className="h-serif mb-3 text-xl font-black">Categories</h2><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{CATEGORIES.map((c) => <div key={c.slug} className="panel flex items-center justify-between gap-2 !p-3"><span className="font-semibold">{c.emoji} {c.name}</span><FollowButton kind="category" target={c.slug} initial={followCats.includes(c.slug)} loggedIn /></div>)}</div></section>
        <section><h2 className="h-serif mb-3 text-xl font-black">Authors</h2><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{authors.map((a) => <div key={a.id} className="panel flex items-center justify-between gap-2 !p-3"><Link href={`/author/${a.slug}`} className="min-w-0"><div className="truncate font-semibold hover:text-brand">{a.name}</div><div className="truncate text-xs text-muted">{a.title}</div></Link><FollowButton kind="author" target={a.slug} initial={followAuthors.includes(a.slug)} loggedIn /></div>)}</div></section>
      </div>
    );
  } else if (tab === "notifications") {
    content = (
      <div>
        <div className="mb-3 flex items-center justify-between"><h2 className="h-serif text-xl font-black">Notification center</h2>{unread > 0 && <ActionButton label="Mark all as read" body={{ action: "notifications" }} />}</div>
        <ul className="space-y-2">{nots.map((n) => <li key={n.id} className={`panel flex items-start gap-3 !p-3 ${n.read ? "" : "!border-brand/50 bg-brand/5"}`}><span className="text-xl">{n.kind === "emergency" ? "🚨" : n.kind === "breaking" ? "⚡" : "🔔"}</span><div className="min-w-0 flex-1"><div className="font-semibold">{n.href ? <Link href={n.href} className="hover:text-brand">{n.title}</Link> : n.title}</div><div className="text-sm text-muted">{n.body}</div><div className="text-xs text-muted">{timeAgo(n.createdAt)}</div></div>{!n.read && <ActionButton label="Mark read" body={{ action: "notifications", ids: [n.id] }} />}</li>)}{!nots.length && <li className="panel text-muted">You're all caught up.</li>}</ul>
      </div>
    );
  } else if (tab === "comments") {
    content = (
      <div><h2 className="h-serif mb-3 text-xl font-black">Comment management</h2><ul className="space-y-3">{myComments.map((c) => <li key={c.id} className="panel flex items-start justify-between gap-4"><div><p>{c.body}</p><div className="mt-1 text-xs text-muted">on <Link href={`/news/${c.slug}#comments`} className="text-brand">{c.title}</Link> · {formatDate(c.at, true)}</div></div><ActionButton label="Delete" body={{ action: "deleteComment", id: c.id }} confirm="Delete this comment?" /></li>)}{!myComments.length && <li className="panel text-muted">You haven't commented yet.</li>}</ul></div>
    );
  } else if (tab === "newsletter") {
    content = <div className="panel max-w-xl"><h2 className="h-serif text-xl font-black">The Trendora Briefing</h2><p className="mb-4 mt-1 text-sm text-muted">A daily email to <b>{user.email}</b>: top stories, one fact-check, one thing to learn.</p><NewsletterToggle email={user.email} subscribed={sub.length > 0} /></div>;
  } else if (tab === "preferences") {
    const p = user.preferences ?? {};
    content = <div className="panel"><h2 className="h-serif mb-4 text-xl font-black">Reading preferences</h2><PrefsForm initial={{ fontSize: p.fontSize ?? 18, lineHeight: p.lineHeight ?? 1.75, view: p.view ?? "grid", theme: p.theme ?? "system" }} /></div>;
  } else {
    const [c] = await db.select({ n: count() }).from(follows).where(and(eq(follows.userId, user.id)));
    content = <div className="panel"><h2 className="h-serif mb-1 text-xl font-black">Account settings</h2><p className="mb-4 text-sm text-muted">Role: {ROLE_LABEL[user.role]} · {Number(c.n)} follows</p><SettingsForm name={user.name} email={user.email} google={false} /></div>;
  }

  return (
    <>
      <PageHero kicker="Your space" title={`Hello, ${user.name.split(" ")[0]} 👋`} sub={`${ROLE_LABEL[user.role]} account · ${user.email}`} />
      <div className="wrap py-6">
        <nav className="no-scrollbar mb-6 flex gap-2 overflow-x-auto" aria-label="Dashboard sections">{TABS.map(([k, l]) => <Link key={k} href={`/dashboard?tab=${k}`} className={`chip shrink-0 !px-4 !py-2 text-sm ${tab === k ? "btn-active" : ""}`}>{l}{k === "notifications" && unread > 0 ? ` (${unread})` : ""}</Link>)}</nav>
        {content}
      </div>
    </>
  );
}
