import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { follows } from "@/db/schema";
import { getUser } from "@/lib/auth";
import { CAT_MAP } from "@/lib/taxonomy";
import { SITE_URL } from "@/lib/utils";
import Listing from "@/components/Listing";
import JsonLd, { breadcrumbLd } from "@/components/JsonLd";
import { FollowButton } from "@/components/Engagement";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ sub?: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const { sub } = await searchParams;
  const c = CAT_MAP[slug];
  if (!c) return { title: "Category not found" };
  const title = sub ? `${sub} — ${c.name} News` : `${c.name} News`;
  return { title, description: c.blurb, alternates: { canonical: sub ? `/category/${slug}?sub=${encodeURIComponent(sub)}` : `/category/${slug}`, types: { "application/rss+xml": `/rss/${slug}` } }, openGraph: { title, description: c.blurb, type: "website" } };
}

export default async function CategoryPage({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ sub?: string }> }) {
  const { slug } = await params;
  const { sub } = await searchParams;
  const c = CAT_MAP[slug];
  if (!c) notFound();
  const user = await getUser();
  const following = user ? (await db.select({ id: follows.id }).from(follows).where(and(eq(follows.userId, user.id), eq(follows.kind, "category"), eq(follows.target, slug))).limit(1)).length > 0 : false;
  return (
    <>
      <JsonLd data={breadcrumbLd(SITE_URL, [{ name: "Home", href: "/" }, { name: c.name, href: `/category/${slug}` }])} />
      <Listing
        kicker={`${c.emoji} Section`}
        title={sub ? `${c.name}: ${sub}` : c.name}
        sub={c.blurb}
        filters={{ category: slug, sub }}
        hero={
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Link href={`/category/${slug}`} className={`chip ${!sub ? "btn-active" : ""}`}>All {c.name}</Link>
            {c.subs.map((s) => <Link key={s} href={`/category/${slug}?sub=${encodeURIComponent(s)}`} className={`chip ${sub === s ? "btn-active" : ""}`}>{s}</Link>)}
            <span className="mx-1 h-5 w-px bg-line" />
            <FollowButton kind="category" target={slug} initial={following} loggedIn={!!user} label={`Follow ${c.name}`} />
            <Link href={`/rss/${slug}`} className="btn btn-sm">📡 RSS</Link>
          </div>
        }
      />
    </>
  );
}
