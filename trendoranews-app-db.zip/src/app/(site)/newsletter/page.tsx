import type { Metadata } from "next";
import { PageHero } from "@/components/cards";
import NewsletterForm from "@/components/NewsletterForm";

export const metadata: Metadata = { title: "Newsletter — The Trendora Briefing", description: "Subscribe to the daily TrendoraNews briefing.", alternates: { canonical: "/newsletter" } };

export default function NewsletterPage() {
  return (
    <>
      <PageHero kicker="Newsletter" title="The Trendora Briefing" sub="The stories that matter, one fact-check and one thing to learn — in your inbox every morning." />
      <div className="wrap py-10"><div className="panel mx-auto max-w-xl"><h2 className="h-serif mb-1 text-xl font-black">Choose your topics</h2><p className="mb-4 text-sm text-muted">Pick the sections you care about most. Unsubscribe any time.</p><NewsletterForm /></div></div>
    </>
  );
}
