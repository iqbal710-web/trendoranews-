import type { ReactNode } from "react";
import { and, eq, count } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getUser } from "@/lib/auth";
import { breakingNow, liveNow } from "@/lib/queries";
import HeaderClient from "@/components/HeaderClient";
import LiveBar from "@/components/LiveBar";
import Footer from "@/components/Footer";
import Tracker from "@/components/Tracker";

export const dynamic = "force-dynamic";

export default async function SiteLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const [user, breaking, live] = await Promise.all([getUser(), breakingNow(), liveNow(20)]);
  let unread = 0;
  if (user) {
    const r = await db.select({ c: count() }).from(notifications).where(and(eq(notifications.userId, user.id), eq(notifications.read, false)));
    unread = Number(r[0]?.c ?? 0);
  }
  const dateStr = new Date().toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
  const bd = { items: breaking.items, alerts: breaking.alerts };
  return (
    <>
      <HeaderClient user={user ? { name: user.name, role: user.role } : null} live={live.length} unread={unread} dateStr={dateStr} />
      <LiveBar initial={bd} />
      <main id="main">{children}</main>
      <Footer />
      <Tracker />
    </>
  );
}
