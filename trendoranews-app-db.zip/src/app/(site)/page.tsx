import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { galleries, videos } from "@/db/schema";
import { getUser } from "@/lib/auth";
import { categoryCounts, countryCounts, latest, popularThisWeek, rank, recommendedFor } from "@/lib/queries";
import { CAT_MAP, REGIONS } from "@/lib/taxonomy";
import { COUNTRY_MAP } from "@/lib/reference";
import { compact, flag } from "@/lib/utils";
import { CompactItem, Kicker, Meta, RankedItem, SectionHeader, StatusBadges, StoryCard, StoryGrid } from "@/components/cards";
import Img from "@/components/Img";
import FeaturedCarousel from "@/components/FeaturedCarousel";
import HomeSections, { type HomeSection } from "@/components/HomeSections";
import InfiniteFeed from "@/components/InfiniteFeed";
import { ViewToggle } from "@/components/Controls";
import NewsletterForm from "@/components/NewsletterForm";

export const dynamic = "force-dynamic";

const TILES = [
  ["/world", "🌐", "Interactive World Map", "See the world's news on a live map"],
  ["/explore/history", "🏛️", "Historical Timeline", "Ancient to modern, event by event"],
  ["/explore/animals", "🐅", "Animal Encyclopedia", "Meet wildlife, pets and marine life"],
  ["/explore/space", "🚀", "Space Explorer", "Planets, missions and telescopes"],
  ["/explore/data", "📊", "Data Visualization", "Charts that make numbers click"],
  ["/fact-check", "✅", "Fact Check Center", "Myths, rumours and the evidence"],
];

export default async function HomePage() {
  const user = await getUser();
  const featured = await rank("featured", 7);
  const lead = featured[0];
  const carousel = featured.slice(1, 7);
  const side = await latest(5, 0, { exclude: lead ? [lead.id] : [] });
  const used = [lead?.id, ...side.map((s) => s.id)].filter(Boolean) as number[];

  const catPicks = ["bangladesh", "world", "technology", "sports", "science", "health"];
  const [top, trending, editors, mostRead, mostShared, popular, recommended, firstLatest, vids, gals, catBlocks, cCounts, catCounts, regionBlocks] = await Promise.all([
    rank("top", 6, used),
    rank("trending", 4, used),
    rank("editors", 6, []),
    rank("read", 5),
    rank("shared", 5),
    popularThisWeek(5),
    recommendedFor(user, 6, used),
    latest(9, 0),
    db.select().from(videos).orderBy(desc(videos.featured), desc(videos.views)).limit(4),
    db.select().from(galleries).orderBy(desc(galleries.publishedAt)).limit(4),
    Promise.all(catPicks.map((c) => latest(4, 0, { category: c }))),
    countryCounts(),
    categoryCounts(),
    Promise.all(REGIONS.map((r) => latest(3, 0, { region: r.slug }))),
  ]);

  const sections: HomeSection[] = [
    {
      id: "hero",
      title: "Hero story & headlines",
      node: lead ? (
        <section aria-label="Top story" className="grid gap-6 lg:grid-cols-12">
          <article className="group relative overflow-hidden rounded-2xl lg:col-span-8">
            <Link href={`/news/${lead.slug}`} className="block aspect-[16/10] sm:aspect-[16/9]">
              <Img src={lead.coverImage} alt={lead.imageAlt ?? lead.title} eager className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
            </Link>
            <div className="absolute inset-x-0 bottom-0 p-5 text-white sm:p-8">
              <StatusBadges c={lead} className="mb-2" />
              <div className="mb-2 text-xs font-bold uppercase tracking-widest text-white/80">{CAT_MAP[lead.category]?.name} {lead.subcategory ? `· ${lead.subcategory}` : ""}</div>
              <h1 className="h-serif text-2xl font-black leading-tight sm:text-4xl lg:text-[2.6rem]"><Link href={`/news/${lead.slug}`} className="hover:underline">{lead.title}</Link></h1>
              <p className="mt-2 line-clamp-2 max-w-2xl text-white/85">{lead.dek}</p>
              <div className="mt-3 text-xs text-white/75">{lead.authorName} · {lead.readingMinutes} min read · {flag(lead.country)}</div>
            </div>
          </article>
          <aside className="lg:col-span-4">
            <div className="kicker mb-1 border-b-2 border-ink pb-2 text-brand">Top headlines</div>
            {side.map((c) => <CompactItem key={c.id} c={c} />)}
          </aside>
        </section>
      ) : <div />,
    },
    { id: "featured", title: "Featured news carousel", node: <section><SectionHeader title="Featured News" kicker="Editors' selection" /><FeaturedCarousel items={carousel} /></section> },
    { id: "top", title: "Top Stories", node: <section><SectionHeader title="Top Stories" href="/category/world" kicker="Most important now" /><StoryGrid items={top} /></section> },
    {
      id: "trending",
      title: "Trending Stories",
      node: (
        <section>
          <SectionHeader title="🔥 Trending Stories" kicker="Rising fast" />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {trending.map((c, i) => (
              <article key={c.id} className="relative overflow-hidden rounded-xl border border-line bg-card p-4 transition hover:shadow-lg">
                <div className="h-serif absolute -right-1 -top-3 text-7xl font-black text-brand/10">{i + 1}</div>
                <Kicker c={c} />
                <h3 className="h-serif mt-1.5 text-lg font-bold leading-snug"><Link href={`/news/${c.slug}`} className="hover:text-brand">{c.title}</Link></h3>
                <div className="mt-2 text-xs text-muted">{compact(c.views)} reads · {c.readingMinutes} min</div>
              </article>
            ))}
          </div>
        </section>
      ),
    },
    {
      id: "editors",
      title: "Editor's Choice",
      node: (
        <section className="-mx-4 rounded-2xl bg-ink px-4 py-8 text-paper sm:-mx-6 sm:px-8">
          <div className="mb-5 flex items-end justify-between border-b border-paper/30 pb-2">
            <div><div className="kicker text-brand">Hand-picked by our editors</div><h2 className="h-serif text-2xl font-black">Editor&apos;s Choice</h2></div>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {editors.slice(0, 3).map((c) => (
              <article key={c.id} className="group">
                <Link href={`/news/${c.slug}`} className="block aspect-[16/10] overflow-hidden rounded-xl"><Img src={c.coverImage} alt={c.imageAlt ?? c.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" /></Link>
                <div className="mt-3 text-[11px] font-bold uppercase tracking-widest text-brand">{CAT_MAP[c.category]?.name}</div>
                <h3 className="h-serif mt-1 text-xl font-bold leading-snug"><Link href={`/news/${c.slug}`} className="hover:underline">{c.title}</Link></h3>
                <p className="mt-1 line-clamp-2 text-sm text-paper/70">{c.dek}</p>
              </article>
            ))}
          </div>
        </section>
      ),
    },
    { id: "mostRead", title: "Most Read", third: true, node: <section className="panel"><SectionHeader title="Most Read" kicker="All time" />{mostRead.map((c, i) => <RankedItem key={c.id} c={c} rank={i + 1} metric={`${compact(c.views)} reads`} />)}</section> },
    { id: "mostShared", title: "Most Shared", third: true, node: <section className="panel"><SectionHeader title="Most Shared" kicker="Across social" />{mostShared.map((c, i) => <RankedItem key={c.id} c={c} rank={i + 1} metric={`${compact(c.shares)} shares`} />)}</section> },
    { id: "popular", title: "Popular This Week", third: true, node: <section className="panel"><SectionHeader title="Popular This Week" kicker="Last 7 days" />{popular.map((c, i) => <RankedItem key={c.id} c={c} rank={i + 1} metric={`${c.readingMinutes} min read · ${CAT_MAP[c.category]?.name}`} />)}</section> },
    {
      id: "recommended",
      title: "Recommended Stories",
      node: (
        <section>
          <SectionHeader title={user ? `Recommended for ${user.name.split(" ")[0]}` : "Recommended Stories"} kicker={user ? "Based on what you follow & read" : "Log in for a personal feed"} href={user ? "/dashboard?tab=feed" : "/register"} />
          <StoryGrid items={recommended} />
        </section>
      ),
    },
    {
      id: "categories",
      title: "News by Category",
      node: (
        <section>
          <SectionHeader title="News by Category" href="/category/bangladesh" kicker="Browse sections" />
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {catPicks.map((slug, i) => {
              const c = CAT_MAP[slug];
              const items = catBlocks[i];
              return (
                <div key={slug} className="panel !p-0 overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3" style={{ background: `${c.color}18`, borderBottom: `3px solid ${c.color}` }}>
                    <Link href={`/category/${slug}`} className="h-serif text-lg font-black">{c.emoji} {c.name}</Link>
                    <span className="text-xs text-muted">{catCounts[slug] ?? 0} stories</span>
                  </div>
                  <div className="px-4 pb-2">{items.slice(0, 4).map((x, k) => <CompactItem key={x.id} c={x} thumb={k === 0} />)}</div>
                </div>
              );
            })}
          </div>
        </section>
      ),
    },
    {
      id: "countries",
      title: "News by Country",
      node: (
        <section>
          <SectionHeader title="News by Country" href="/world" kicker="Around the globe" />
          <div className="flex flex-wrap gap-2">
            {Object.entries(cCounts).sort((a, b) => b[1] - a[1]).slice(0, 24).map(([code, n]) => (
              <Link key={code} href={`/country/${code.toLowerCase()}`} className="chip !px-3 !py-1.5 text-sm">
                <span className="text-lg leading-none">{flag(code)}</span> {COUNTRY_MAP[code]?.name ?? code} <b className="text-brand">{n}</b>
              </Link>
            ))}
          </div>
        </section>
      ),
    },
    {
      id: "regions",
      title: "News by Region",
      node: (
        <section>
          <SectionHeader title="News by Region" kicker="Regional desks" />
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {REGIONS.map((r, i) => (
              <div key={r.slug} className="panel">
                <Link href={`/region/${r.slug}`} className="h-serif text-lg font-black hover:text-brand">{r.name} →</Link>
                <ul className="mt-2 space-y-2 text-sm">
                  {regionBlocks[i].map((c) => <li key={c.id} className="border-t border-line/70 pt-2"><Link href={`/news/${c.slug}`} className="font-medium hover:text-brand">{flag(c.country)} {c.title}</Link></li>)}
                  {!regionBlocks[i].length && <li className="text-muted">No stories yet.</li>}
                </ul>
              </div>
            ))}
          </div>
        </section>
      ),
    },
    {
      id: "videos",
      title: "Videos",
      node: (
        <section>
          <SectionHeader title="Watch" href="/videos" kicker="TrendoraNews Video" />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {vids.map((v) => (
              <Link key={v.id} href={`/videos/${v.slug}`} className="group overflow-hidden rounded-xl border border-line bg-card">
                <div className="relative aspect-video overflow-hidden"><Img src={v.poster} alt={v.title} className="h-full w-full object-cover transition group-hover:scale-105" /><span className="absolute inset-0 flex items-center justify-center"><span className="flex h-12 w-12 items-center justify-center rounded-full bg-black/60 text-xl text-white">▶</span></span></div>
                <div className="p-3"><div className="kicker text-brand">{v.category}</div><h3 className="mt-0.5 line-clamp-2 text-sm font-bold">{v.title}</h3><div className="mt-1 text-xs text-muted">{compact(v.views)} views</div></div>
              </Link>
            ))}
          </div>
        </section>
      ),
    },
    {
      id: "photos",
      title: "Photo galleries",
      node: (
        <section>
          <SectionHeader title="In Pictures" href="/photos" kicker="Photography" />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {gals.map((g) => (
              <Link key={g.id} href={`/photos/${g.slug}`} className="group relative aspect-[4/3] overflow-hidden rounded-xl">
                <Img src={g.coverImage} alt={g.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-3 text-white"><div className="text-[10px] font-bold uppercase tracking-widest text-white/70">{g.kind.replace("_", " ")} · {g.images.length} photos</div><div className="h-serif font-bold leading-snug">{g.title}</div></div>
              </Link>
            ))}
          </div>
        </section>
      ),
    },
    {
      id: "explore",
      title: "Interactive explorers",
      node: (
        <section>
          <SectionHeader title="Explore & Learn" kicker="Interactive" href="/explore" />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {TILES.map(([h, e, t, d]) => (
              <Link key={h} href={h} className="group flex items-center gap-4 rounded-xl border border-line bg-card p-4 transition hover:border-brand hover:shadow-lg">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand/10 text-2xl">{e}</span>
                <span><span className="block font-bold group-hover:text-brand">{t}</span><span className="text-sm text-muted">{d}</span></span>
              </Link>
            ))}
          </div>
        </section>
      ),
    },
    {
      id: "newsletter",
      title: "Newsletter",
      node: (
        <section className="rounded-2xl bg-brand/10 p-6 sm:p-10">
          <div className="grid items-center gap-6 md:grid-cols-2">
            <div><div className="kicker text-brand">The Trendora Briefing</div><h2 className="h-serif mt-1 text-3xl font-black">Start your day informed.</h2><p className="mt-2 text-muted">One email every morning: the stories that matter, a fact-check, and one thing to learn. Free, always.</p></div>
            <NewsletterForm />
          </div>
        </section>
      ),
    },
    {
      id: "latest",
      title: "Latest News (infinite scroll)",
      node: (
        <section>
          <SectionHeader title="Latest News" kicker="Newest first" right={<ViewToggle />} />
          <InfiniteFeed initial={firstLatest} pageSize={9} />
        </section>
      ),
    },
  ];

  const prefs = user?.preferences ?? {};
  return <HomeSections sections={sections} initialHidden={prefs.hidden ?? []} initialOrder={prefs.order ?? []} loggedIn={!!user} />;
}

void StoryCard;
void Meta;
