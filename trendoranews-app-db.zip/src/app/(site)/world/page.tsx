import type { Metadata } from "next";
import { countryCounts, latest } from "@/lib/queries";
import { getWorldMap } from "@/lib/worldmap";
import { PageHero } from "@/components/cards";
import WorldMap from "@/components/explore/WorldMap";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Interactive World News Map", description: "Explore the world's news on an interactive map. Click any country for the latest stories and key facts.", alternates: { canonical: "/world" } };

export default async function WorldPage() {
  const [counts, items] = await Promise.all([countryCounts(), latest(100, 0)]);
  const stories: Record<string, { slug: string; title: string; publishedAt: string; category: string }[]> = {};
  for (const i of items) {
    if (!i.country) continue;
    (stories[i.country] ??= []).length < 5 && stories[i.country].push({ slug: i.slug, title: i.title, publishedAt: i.publishedAt, category: i.category });
  }
  return (
    <>
      <PageHero kicker="Interactive" title="World news map" sub="See where the stories are happening. Pan, zoom and click a country for its latest coverage." />
      <div className="wrap py-8"><WorldMap map={getWorldMap()} counts={counts} stories={stories} /></div>
    </>
  );
}
