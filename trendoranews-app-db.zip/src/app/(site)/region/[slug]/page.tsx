import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { REGIONS, REGION_MAP } from "@/lib/taxonomy";
import { COUNTRIES } from "@/lib/reference";
import { flag } from "@/lib/utils";
import Listing from "@/components/Listing";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const n = REGION_MAP[slug];
  return n ? { title: `${n} news`, description: `Regional coverage from ${n}.`, alternates: { canonical: `/region/${slug}` } } : { title: "Region not found" };
}

export default async function RegionPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!REGION_MAP[slug]) notFound();
  return (
    <Listing
      kicker="Region"
      title={`${REGION_MAP[slug]} news`}
      sub="Stories filed by our regional desks and correspondents."
      filters={{ region: slug }}
      hero={
        <div className="mt-4 flex flex-wrap gap-2">
          {REGIONS.map((r) => <Link key={r.slug} href={`/region/${r.slug}`} className={`chip ${r.slug === slug ? "btn-active" : ""}`}>{r.name}</Link>)}
          <span className="mx-1 h-5 w-px bg-line" />
          {COUNTRIES.filter((c) => c.region === slug).slice(0, 10).map((c) => <Link key={c.code} href={`/country/${c.code.toLowerCase()}`} className="chip">{flag(c.code)} {c.name}</Link>)}
        </div>
      }
    />
  );
}
