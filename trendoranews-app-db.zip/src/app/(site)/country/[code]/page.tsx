import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { COUNTRY_MAP } from "@/lib/reference";
import { REGION_MAP } from "@/lib/taxonomy";
import { flag } from "@/lib/utils";
import Listing from "@/components/Listing";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ code: string }> }): Promise<Metadata> {
  const { code } = await params;
  const c = COUNTRY_MAP[code.toUpperCase()];
  if (!c) return { title: "Country not found" };
  return { title: `${c.name} news`, description: `Latest news from ${c.name}: ${c.fact}`, alternates: { canonical: `/country/${code.toLowerCase()}` } };
}

export default async function CountryPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const c = COUNTRY_MAP[code.toUpperCase()];
  if (!c) notFound();
  return (
    <Listing
      kicker={`${flag(c.code)} Country · ${REGION_MAP[c.region]}`}
      title={`${c.name} news`}
      sub={c.fact}
      filters={{ country: c.code }}
      extra={
        <div className="panel mb-6 grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-5">
          {[["Capital", c.capital], ["Population", `${c.population}M`], ["Area", `${c.area.toLocaleString()}k km²`], ["Languages", c.languages], ["Currency", c.currency]].map(([k, v]) => <div key={k}><div className="kicker text-muted">{k}</div><div className="font-bold">{v}</div></div>)}
          <div className="sm:col-span-2 lg:col-span-5"><Link href={`/explore/geography?c=${c.code}`} className="btn btn-sm">🗺️ Open in Country Explorer</Link> <Link href="/world" className="btn btn-sm">🌐 World map</Link></div>
        </div>
      }
    />
  );
}
