import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { and, asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { articleVersions, bookmarks, follows, reactions } from "@/db/schema";
import { getUser, isStaff } from "@/lib/auth";
import { getArticleBySlug, getComments, getLiveUpdates, moreFromAuthor, rank, relatedTo, youMayAlsoLike } from "@/lib/queries";
import { CAT_MAP, REGION_MAP } from "@/lib/taxonomy";
import { COUNTRY_MAP } from "@/lib/reference";
import { SITE_NAME, SITE_URL, compact, flag, formatDate, parseBody, timeAgo } from "@/lib/utils";
import ArticleReader from "@/components/ArticleReader";
import { Comments, EngagementBar, FollowButton } from "@/components/Engagement";
import LiveFeed from "@/components/LiveFeed";
import JsonLd, { breadcrumbLd } from "@/components/JsonLd";
import Img from "@/components/Img";
import NewsletterForm from "@/components/NewsletterForm";
import { CompactItem, FactBadge, RankedItem, SectionHeader, StatusBadges, StoryGrid, VerifiedBadge } from "@/components/cards";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const row = await getArticleBySlug(slug);
  if (!row) return { title: "Story not found" };
  const a = row.a;
  const title = a.seoTitle || a.title;
  const description = a.seoDescription || a.dek;
  const url = `/news/${a.slug}`;
  const images = a.coverImage ? [{ url: a.coverImage, alt: a.imageAlt ?? a.title, width: 1200, height: 627 }] : [];
  return {
    title,
    description,
    keywords: a.tags,
    alternates: { canonical: url },
    robots: a.status === "published" ? { index: true, follow: true, "max-image-preview": "large" } : { index: false, follow: false },
    openGraph: { type: "article", title, description, url, siteName: SITE_NAME, publishedTime: a.publishedAt?.toISOString(), modifiedTime: a.updatedAt.toISOString(), authors: row.author ? [row.author.name] : undefined, section: CAT_MAP[a.category]?.name, tags: a.tags, images },
    twitter: { card: "summary_large_image", title, description, images: images.map((i) => i.url) },
    other: { news_keywords: a.tags.join(", ") },
  };
}

export default async function ArticlePage({ params, searchParams }: { params: Promise<{ slug: string }>; searchParams: Promise<{ preview?: string }> }) {
  const { slug } = await params;
  const sp = await searchParams;
  const row = await getArticleBySlug(slug);
  if (!row) notFound();
  const { a, author } = row;
  const user = await getUser();
  const isLiveNow = a.status === "published" || (a.status === "scheduled" && a.publishedAt && a.publishedAt <= new Date());
  if (!isLiveNow && !(user && isStaff(user.role))) notFound();

  const cat = CAT_MAP[a.category];
  const [related, more, comments, updates, versions, mostRead] = await Promise.all([
    relatedTo({ id: a.id, category: a.category, tags: a.tags }, 4),
    a.authorId ? moreFromAuthor(a.authorId, a.id, 3) : Promise.resolve([]),
    getComments(a.id),
    getLiveUpdates(a.id),
    db.select().from(articleVersions).where(eq(articleVersions.articleId, a.id)).orderBy(asc(articleVersions.version)),
    rank("read", 5, [a.id]),
  ]);
  const like = await youMayAlsoLike([a.id, ...related.map((r) => r.id), ...more.map((r) => r.id)], a.category, 4);

  let liked = false, bookmarked = false, followsAuthor = false;
  if (user) {
    liked = (await db.select({ id: reactions.id }).from(reactions).where(and(eq(reactions.articleId, a.id), eq(reactions.userKey, `u:${user.id}`))).limit(1)).length > 0;
    bookmarked = (await db.select({ id: bookmarks.id }).from(bookmarks).where(and(eq(bookmarks.userId, user.id), eq(bookmarks.articleId, a.id))).limit(1)).length > 0;
    if (author) followsAuthor = (await db.select({ id: follows.id }).from(follows).where(and(eq(follows.userId, user.id), eq(follows.kind, "author"), eq(follows.target, author.slug))).limit(1)).length > 0;
  }

  const blocks = parseBody(a.body);
  const breakingActive = a.isBreaking && (!a.breakingUntil || a.breakingUntil > new Date());
  const badge = { isBreaking: breakingActive, isLive: a.isLive, isDeveloping: a.isDeveloping, updatedAt: a.updatedAt.toISOString(), publishedAt: (a.publishedAt ?? a.createdAt).toISOString() };
  const wasUpdated = a.publishedAt && a.updatedAt.getTime() - a.publishedAt.getTime() > 5 * 60_000;
  const url = `${SITE_URL}/news/${a.slug}`;
  const isLiveBlog = a.type === "live" || a.isLive || updates.length > 0 && a.type === "live";

  const ld: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": isLiveBlog ? "LiveBlogPosting" : "NewsArticle",
    headline: a.title.slice(0, 110),
    description: a.dek,
    image: a.coverImage ? [a.coverImage] : undefined,
    datePublished: a.publishedAt?.toISOString(),
    dateModified: a.updatedAt.toISOString(),
    author: author ? { "@type": "Person", name: author.name, url: `${SITE_URL}/author/${author.slug}`, jobTitle: author.title } : { "@type": "Organization", name: SITE_NAME },
    publisher: { "@type": "NewsMediaOrganization", name: SITE_NAME, logo: { "@type": "ImageObject", url: `${SITE_URL}/icon.svg` } },
    mainEntityOfPage: { "@type": "WebPage", "@id": url },
    articleSection: cat?.name,
    keywords: a.tags.join(", "),
    wordCount: a.body.split(/\s+/).length,
    isAccessibleForFree: true,
    inLanguage: "en",
    ...(a.corrections.length ? { correction: a.corrections.map((c) => c.note).join(" ") } : {}),
    ...(isLiveBlog ? { coverageStartTime: a.createdAt.toISOString(), liveBlogUpdate: updates.slice(0, 10).map((u) => ({ "@type": "BlogPosting", headline: u.title, articleBody: u.body, datePublished: u.createdAt })) } : {}),
  };
  const crumbs = [{ name: "Home", href: "/" }, { name: cat?.name ?? a.category, href: `/category/${a.category}` }, ...(a.subcategory ? [{ name: a.subcategory, href: `/category/${a.category}?sub=${encodeURIComponent(a.subcategory)}` }] : []), { name: a.title, href: `/news/${a.slug}` }];

  return (
    <>
      <JsonLd data={ld} />
      <JsonLd data={breadcrumbLd(SITE_URL, crumbs)} />
      {!isLiveNow && (
        <div className="bg-amber-400 py-2 text-center text-sm font-bold text-black">PREVIEW — this story is “{a.status.replace("_", " ")}” and not visible to the public{sp.preview ? "" : ""}. <Link href={`/studio/articles/${a.id}`} className="underline">Back to editor</Link></div>
      )}
      <div className="wrap article-shell grid gap-10 py-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <article className="min-w-0">
          <nav aria-label="Breadcrumb" className="chrome mb-4 flex flex-wrap items-center gap-1.5 text-xs text-muted">
            {crumbs.slice(0, -1).map((c, i) => <span key={c.href} className="flex items-center gap-1.5">{i > 0 && <span>›</span>}<Link href={c.href} className="hover:text-brand">{c.name}</Link></span>)}
          </nav>

          <header>
            <div className="flex flex-wrap items-center gap-2">
              <StatusBadges c={badge} />
              <Link href={`/category/${a.category}`} className="kicker" style={{ color: cat?.color }}>{cat?.name}{a.subcategory ? ` / ${a.subcategory}` : ""}</Link>
              {a.type !== "news" && <span className="rounded bg-soft px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-muted">{a.type.replace("-", " ")}</span>}
              {a.editorialLabel && <span className="rounded border border-line px-2 py-0.5 text-[11px] font-semibold text-muted">🛡 {a.editorialLabel}</span>}
            </div>
            <h1 className="h-serif mt-3 text-3xl font-black leading-[1.1] tracking-tight sm:text-4xl lg:text-5xl">{a.title}</h1>
            <p className="mt-3 text-lg text-muted sm:text-xl">{a.dek}</p>

            <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-3 border-y border-line py-3 text-sm">
              {author && (
                <Link href={`/author/${author.slug}`} className="flex items-center gap-2.5">
                  <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand/15 font-black text-brand">{author.name[0]}</span>
                  <span><span className="flex items-center gap-1 font-bold">{author.name}{author.verified && <VerifiedBadge />}</span><span className="block text-xs text-muted">{author.title}</span></span>
                </Link>
              )}
              <div className="text-xs text-muted">
                <div><b className="text-ink">Published</b> {formatDate(a.publishedAt, true)}</div>
                {wasUpdated && <div><b className="text-ink">Last updated</b> {formatDate(a.updatedAt, true)} ({timeAgo(a.updatedAt)})</div>}
              </div>
              <div className="text-xs text-muted">⏱ {a.readingMinutes} min read · 👁 {compact(a.views)} reads{a.country && <> · {flag(a.country)} {COUNTRY_MAP[a.country]?.name}</>}{a.region && <> · {REGION_MAP[a.region]}</>}</div>
              <FactBadge status={a.factStatus} className="ml-auto" />
            </div>
            <div className="mt-4"><EngagementBar articleId={a.id} slug={a.slug} title={a.title} likes={a.likes} shares={a.shares} liked={liked} bookmarked={bookmarked} loggedIn={!!user} /></div>
          </header>

          {a.coverImage && (
            <figure className="mt-6">
              <Img src={a.coverImage} alt={a.imageAlt ?? a.title} eager className="aspect-[16/9] w-full rounded-xl object-cover" />
              <figcaption className="mt-1.5 text-xs text-muted">{a.imageAlt}{a.imageCredit ? ` · Photo: ${a.imageCredit}` : ""}</figcaption>
            </figure>
          )}

          {a.corrections.length > 0 && (
            <div className="mt-6 rounded-xl border border-amber-500/40 bg-amber-500/10 p-4 text-sm" role="note">
              <b>✎ Correction{a.corrections.length > 1 ? "s" : ""}</b>
              <ul className="mt-1 space-y-1">{a.corrections.map((c, i) => <li key={i}><span className="text-xs text-muted">{formatDate(c.date)} —</span> {c.note}</li>)}</ul>
            </div>
          )}

          <div className="mt-8">
            <ArticleReader articleId={a.id} slug={a.slug} title={a.title} minutes={a.readingMinutes} loggedIn={!!user} initial={{ fontSize: user?.preferences?.fontSize, lineHeight: user?.preferences?.lineHeight }}>
              {blocks.map((b, i) =>
                b.t === "h" ? <h2 key={i}>{b.text}</h2> : b.t === "q" ? <blockquote key={i}>{b.text}</blockquote> : b.t === "ul" ? <ul key={i}>{b.items.map((it, k) => <li key={k}>{it}</li>)}</ul> : <p key={i}>{b.text}</p>,
              )}
            </ArticleReader>
          </div>

          {(isLiveBlog || updates.length > 0) && <div className="mt-10"><LiveFeed articleId={a.id} initial={updates} isLive={a.isLive} /></div>}

          {a.tags.length > 0 && (
            <div className="mt-8 flex flex-wrap items-center gap-2"><span className="kicker text-muted">Tags</span>{a.tags.map((t) => <Link key={t} href={`/tag/${encodeURIComponent(t)}`} className="chip">#{t}</Link>)}</div>
          )}

          <section className="mt-10 grid gap-4 md:grid-cols-2">
            <div className="panel">
              <h2 className="h-serif text-lg font-black">Sources & references</h2>
              <ol className="mt-2 list-decimal space-y-1.5 pl-5 text-sm">{a.sources.map((s, i) => <li key={i}><a href={s.url} target="_blank" rel="noopener noreferrer nofollow" className="text-brand hover:underline">{s.title}</a></li>)}{!a.sources.length && <li className="list-none text-muted">No external sources listed.</li>}</ol>
            </div>
            <div className="panel">
              <h2 className="h-serif text-lg font-black">Editorial standards</h2>
              <dl className="mt-2 space-y-2 text-sm">
                <div className="flex items-center justify-between gap-2"><dt className="text-muted">Fact-check status</dt><dd><FactBadge status={a.factStatus} /></dd></div>
                <div className="flex items-center justify-between gap-2"><dt className="text-muted">Editorial review</dt><dd className="font-semibold">{a.editorialLabel ?? "Standard editorial review"}</dd></div>
                <div className="flex items-center justify-between gap-2"><dt className="text-muted">Version</dt><dd className="font-semibold">v{a.version}</dd></div>
                <div className="flex items-center justify-between gap-2"><dt className="text-muted">Corrections</dt><dd className="font-semibold">{a.corrections.length || "None"}</dd></div>
              </dl>
              <Link href="/about" className="mt-2 inline-block text-xs text-brand">How we report →</Link>
            </div>
          </section>

          {(versions.length > 0 || wasUpdated || a.corrections.length > 0) && (
            <section className="panel mt-4">
              <h2 className="h-serif text-lg font-black">Update timeline & revision history</h2>
              <ol className="relative mt-3 space-y-3 border-l-2 border-line pl-5 text-sm">
                <li className="relative"><span className="absolute -left-[27px] top-1 h-3 w-3 rounded-full bg-brand" /><b>Published</b> <span className="text-muted">· {formatDate(a.publishedAt, true)}</span></li>
                {versions.map((v) => <li key={v.id} className="relative"><span className="absolute -left-[27px] top-1 h-3 w-3 rounded-full bg-sky-500" /><b>Version {v.version}</b> <span className="text-muted">· {formatDate(v.createdAt, true)} · {v.editorName}</span><div className="text-muted">{v.note}</div></li>)}
                {a.corrections.map((c, i) => <li key={i} className="relative"><span className="absolute -left-[27px] top-1 h-3 w-3 rounded-full bg-amber-500" /><b>Correction</b> <span className="text-muted">· {formatDate(c.date, true)}</span><div>{c.note}</div></li>)}
                {wasUpdated && <li className="relative"><span className="absolute -left-[27px] top-1 h-3 w-3 rounded-full bg-emerald-500" /><b>Last updated</b> <span className="text-muted">· {formatDate(a.updatedAt, true)}</span></li>}
              </ol>
            </section>
          )}

          <div className="mt-8 border-t border-line pt-6"><EngagementBar articleId={a.id} slug={a.slug} title={a.title} likes={a.likes} shares={a.shares} liked={liked} bookmarked={bookmarked} loggedIn={!!user} /></div>

          {author && (
            <section className="chrome panel mt-8 flex flex-col gap-4 sm:flex-row" aria-label="About the author">
              <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-brand/15 text-2xl font-black text-brand">{author.name[0]}</span>
              <div className="flex-1">
                <div className="kicker text-muted">About the author</div>
                <h2 className="h-serif flex items-center gap-1.5 text-xl font-black"><Link href={`/author/${author.slug}`} className="hover:text-brand">{author.name}</Link>{author.verified && <><VerifiedBadge /><span className="text-xs font-semibold text-sky-600">Verified journalist</span></>}</h2>
                <div className="text-sm text-muted">{author.title}{author.country ? ` · ${flag(author.country)} ${COUNTRY_MAP[author.country]?.name ?? ""}` : ""}</div>
                <p className="mt-2 text-sm">{author.bio}</p>
                <div className="mt-3 flex gap-2"><FollowButton kind="author" target={author.slug} initial={followsAuthor} loggedIn={!!user} label="Follow author" /><Link href={`/author/${author.slug}`} className="btn btn-sm">View profile</Link></div>
              </div>
            </section>
          )}

          <div className="mt-10"><Comments articleId={a.id} initial={comments.map((c) => ({ ...c, createdAt: c.createdAt.toISOString() }))} user={user ? { id: user.id, name: user.name, role: user.role } : null} /></div>

          <div className="chrome mt-12 space-y-10">
            {more.length > 0 && author && <section><SectionHeader title={`More from ${author.name}`} href={`/author/${author.slug}`} /><StoryGrid items={more} /></section>}
            {related.length > 0 && <section><SectionHeader title="Related stories" kicker="Keep reading" /><StoryGrid items={related} cols={2} /></section>}
            {like.length > 0 && <section><SectionHeader title="You may also like" /><StoryGrid items={like} cols={4} /></section>}
          </div>
        </article>

        <aside className="chrome-aside space-y-6 lg:sticky lg:top-28 lg:self-start">
          <div className="panel">
            <SectionHeader title="Most Read" />
            {mostRead.map((c, i) => <RankedItem key={c.id} c={c} rank={i + 1} metric={`${compact(c.views)} reads`} />)}
          </div>
          <div className="panel"><div className="kicker text-brand">Newsletter</div><h3 className="h-serif mb-2 text-lg font-black">Get the Trendora Briefing</h3><NewsletterForm compact /></div>
          <div className="panel"><div className="kicker text-brand">Think it&apos;s false?</div><p className="mb-2 mt-1 text-sm text-muted">Send a claim to our fact-checkers.</p><Link href="/fact-check" className="btn btn-sm">Open Fact Check Center</Link></div>
          {related.slice(0, 3).map((c) => <CompactItem key={c.id} c={c} />)}
        </aside>
      </div>
    </>
  );
}
