import Link from "next/link";
import type { Metadata } from "next";
import { desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { alerts, articles, liveUpdates } from "@/db/schema";
import { breakingActive, getCards, rank } from "@/lib/queries";
import { formatDate, timeAgo } from "@/lib/utils";
import { CompactItem, PageHero, StatusBadges, StoryGrid } from "@/components/cards";
import Img from "@/components/Img";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Live Centre — breaking news, live blogs & alerts", description: "Real-time breaking news, live event coverage, developing stories and emergency alerts.", alternates: { canonical: "/live" } };

export default async function LivePage() {
  const [live, breaking, developing, ended, al, trending] = await Promise.all([
    getCards({ where: [eq(articles.isLive, true)], limit: 6 }),
    getCards({ where: [breakingActive()], limit: 8 }),
    getCards({ where: [eq(articles.isDeveloping, true)], limit: 6 }),
    getCards({ where: [eq(articles.type, "live"), eq(articles.isLive, false)], limit: 6 }),
    db.select().from(alerts).orderBy(desc(alerts.createdAt)).limit(8),
    rank("trending", 4),
  ]);
  const ids = live.map((l) => l.id);
  const ups = ids.length ? await db.select().from(liveUpdates).where(inArray(liveUpdates.articleId, ids)).orderBy(desc(liveUpdates.createdAt)) : [];
  return (
    <>
      <PageHero kicker="Real-time" title="Live Centre" sub="Live blogs, breaking news, developing stories and emergency alerts — updated as it happens." />
      <div className="wrap space-y-12 py-8">
        <section>
          <h2 className="h-serif mb-4 flex items-center gap-2 text-2xl font-black"><span className="live-dot" /> Live now</h2>
          {live.length ? (
            <div className="grid gap-6 lg:grid-cols-2">
              {live.map((c) => {
                const mine = ups.filter((u) => u.articleId === c.id);
                return (
                  <article key={c.id} className="overflow-hidden rounded-2xl border border-brand/40 bg-card">
                    <Link href={`/news/${c.slug}`} className="relative block aspect-[16/7]"><Img src={c.coverImage} alt={c.title} className="h-full w-full object-cover" /><StatusBadges c={c} className="absolute left-3 top-3" /></Link>
                    <div className="p-5">
                      <h3 className="h-serif text-2xl font-black leading-snug"><Link href={`/news/${c.slug}`} className="hover:text-brand">{c.title}</Link></h3>
                      <p className="mt-1 text-sm text-muted">{mine.length} updates · started {timeAgo(c.publishedAt)}</p>
                      <ul className="mt-3 space-y-2 border-l-2 border-brand/40 pl-3 text-sm">
                        {mine.slice(0, 3).map((u) => <li key={u.id}><b className="text-xs text-muted">{timeAgo(u.createdAt)}</b><div className="font-semibold">{u.title}</div></li>)}
                      </ul>
                      <Link href={`/news/${c.slug}#live`} className="btn btn-primary btn-sm mt-4">Follow live →</Link>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : <div className="panel text-muted">No live events right now. Check back soon.</div>}
        </section>

        <div className="grid gap-8 lg:grid-cols-3">
          <section className="panel lg:col-span-2">
            <h2 className="h-serif text-xl font-black">Breaking news</h2>
            <p className="text-xs text-muted">Breaking labels expire automatically after the window set by editors.</p>
            {breaking.map((c) => <CompactItem key={c.id} c={c} />)}
            {!breaking.length && <p className="py-4 text-sm text-muted">Nothing breaking at the moment.</p>}
          </section>
          <section className="panel">
            <h2 className="h-serif text-xl font-black">Alert history</h2>
            <ul className="mt-2 space-y-3 text-sm">
              {al.map((a) => (
                <li key={a.id} className="border-b border-line pb-2 last:border-0">
                  <span className={`mr-1 rounded px-1.5 py-0.5 text-[10px] font-extrabold uppercase text-white ${a.level === "emergency" ? "bg-brand" : a.level === "breaking" ? "bg-black" : "bg-sky-600"}`}>{a.level}</span>
                  <span className="text-xs text-muted">{formatDate(a.createdAt, true)}{a.active && (!a.expiresAt || a.expiresAt > new Date()) ? " · active" : " · expired"}</span>
                  <div className="mt-1">{a.headline}</div>
                </li>
              ))}
            </ul>
            <p className="mt-3 rounded-lg bg-soft p-3 text-xs text-muted">🔔 Enable browser alerts from the ticker bar to get breaking and emergency notifications while TrendoraNews is open.</p>
          </section>
        </div>

        {developing.length > 0 && <section><h2 className="h-serif mb-4 text-2xl font-black">Developing stories</h2><StoryGrid items={developing} /></section>}
        {ended.length > 0 && <section><h2 className="h-serif mb-4 text-2xl font-black">Past live coverage</h2><StoryGrid items={ended} /></section>}
        <section><h2 className="h-serif mb-4 text-2xl font-black">Trending now</h2><StoryGrid items={trending} cols={4} /></section>
      </div>
    </>
  );
}
