import { Suspense } from "react";
import type { Metadata } from "next";
import { getAuthors } from "@/lib/queries";
import { trending } from "@/lib/search";
import { PageHero } from "@/components/cards";
import SearchClient from "@/components/SearchClient";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Search", description: "Instantly search TrendoraNews by keyword, author, category, country, tag, date and article type.", alternates: { canonical: "/search" } };

export default async function SearchPage() {
  const [authors, tr] = await Promise.all([getAuthors("journalist"), trending(10)]);
  return (
    <>
      <PageHero kicker="Instant search" title="Search TrendoraNews" sub="Live suggestions, typo correction and powerful filters." />
      <Suspense>
        <SearchClient opts={{ authors: authors.map((a) => ({ slug: a.slug, name: a.name })), trending: tr }} />
      </Suspense>
    </>
  );
}
