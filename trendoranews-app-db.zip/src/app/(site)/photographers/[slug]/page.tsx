import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { galleries } from "@/db/schema";
import { getAuthor } from "@/lib/queries";
import { COUNTRY_MAP } from "@/lib/reference";
import { flag } from "@/lib/utils";
import { PageHero, VerifiedBadge } from "@/components/cards";
import Img from "@/components/Img";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const p = await getAuthor(slug);
  return p ? { title: `${p.name} — photographer`, description: p.bio ?? undefined, alternates: { canonical: `/photographers/${slug}` } } : { title: "Photographer not found" };
}

export default async function PhotographerPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = await getAuthor(slug);
  if (!p || p.kind !== "photographer") notFound();
  const gs = await db.select().from(galleries).where(eq(galleries.photographerId, p.id)).orderBy(desc(galleries.publishedAt));
  return (
    <>
      <PageHero kicker="Photographer profile" title={p.name} sub={p.title ?? undefined}>
        <div className="mt-4 flex items-start gap-4">
          <span className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full bg-brand/15 text-3xl font-black text-brand">{p.name[0]}</span>
          <div className="max-w-2xl"><div className="flex items-center gap-2 text-sm text-muted">{p.verified && <span className="inline-flex items-center gap-1 font-semibold text-sky-600"><VerifiedBadge /> Verified</span>}{p.country && <span>{flag(p.country)} {COUNTRY_MAP[p.country]?.name}</span>}</div><p className="mt-2">{p.bio}</p></div>
        </div>
      </PageHero>
      <div className="wrap py-8">
        <h2 className="h-serif mb-4 text-2xl font-black">Work by {p.name}</h2>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {gs.map((g) => <Link key={g.id} href={`/photos/${g.slug}`} className="group relative aspect-[4/3] overflow-hidden rounded-xl"><Img src={g.coverImage} alt={g.title} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" /><div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" /><div className="absolute inset-x-0 bottom-0 p-3 text-white"><div className="text-[10px] font-bold uppercase tracking-widest text-white/70">{g.kind.replace("_", " ")}</div><div className="h-serif font-bold">{g.title}</div></div></Link>)}
          {!gs.length && <p className="text-muted">No galleries yet.</p>}
        </div>
      </div>
    </>
  );
}
