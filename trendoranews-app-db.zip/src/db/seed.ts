import { count, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  alerts, articleVersions, articles, authors, bookmarks, comments, events, factChecks, follows, galleries,
  liveUpdates, mediaAssets, notifications, playlists, readingHistory, searchLogs, subscribers, users, videos,
  type Cue, type GalleryImage,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { COUNTRY_MAP } from "@/lib/reference";
import { px, readingMinutes, slugify, titleKey } from "@/lib/utils";
import { ARTICLES, AUTHORS, CTX, DEMO_USERS, FACT_CHECKS, IMAGES, SEARCH_QUERIES, SUBMITTED_CLAIMS } from "@/db/seed-data";

function rng(seed: number) {
  let t = seed;
  return () => {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function cuesFrom(lines: string[], step: number): Cue[] {
  return lines.map((text, i) => ({ start: i * step, end: (i + 1) * step - 0.2, text }));
}

const VBASE = "https://storage.googleapis.com/gtv-videos-bucket/sample/";

export async function seedIfEmpty() {
  const r = await db.select({ c: count() }).from(articles);
  if (Number(r[0].c) > 0) return false;
  await runSeed();
  return true;
}

let seeding: Promise<void> | null = null;
export function ensureSeeded() {
  if (!seeding) {
    seeding = seedIfEmpty()
      .then(() => undefined)
      .catch(() => {
        seeding = null;
      });
  }
  return seeding;
}

export async function runSeed() {
  const rand = rng(42);
  const now = Date.now();
  const ago = (h: number) => new Date(now - h * 3600_000);

  await db.execute(
    sql`truncate table users, sessions, authors, articles, article_versions, comments, reactions, bookmarks, reading_history, follows, notifications, live_updates, alerts, playlists, videos, galleries, media_assets, subscribers, search_logs, events, fact_checks restart identity`,
  );

  // authors
  const authorRows = await db
    .insert(authors)
    .values(AUTHORS.map((a) => ({ ...a, avatar: null, twitter: `@${a.slug.replace(/-/g, "_")}` })))
    .returning({ id: authors.id, slug: authors.slug });
  const authorId = Object.fromEntries(authorRows.map((a) => [a.slug, a.id]));

  // users
  const pw = hashPassword("demo1234");
  const userRows = await db
    .insert(users)
    .values(DEMO_USERS.map((u) => ({ email: u.email, name: u.name, role: u.role, passwordHash: pw, authorId: u.author ? authorId[u.author] : null })))
    .returning({ id: users.id, email: users.email, role: users.role, name: users.name });
  const reader = userRows.find((u) => u.role === "reader")!;
  const editorUser = userRows.find((u) => u.role === "editor")!;

  // articles
  const catCount: Record<string, number> = {};
  const values = ARTICLES.map((a, i) => {
    const idx = (catCount[a.c] = (catCount[a.c] ?? -1) + 1);
    const pool = IMAGES[a.c];
    const ty = a.ty ?? "news";
    const ctx = CTX[ty] ?? CTX.analysis;
    const fl = a.fl ?? "";
    const tags = a.tags.map((t) => t.toLowerCase());
    const bullets = [
      `- Official statements and fresh data on ${tags[0]}`,
      `- How ${tags[1] ?? tags[0]} shapes the wider debate`,
      `- Reactions from readers and experts — share yours in the comments`,
    ].join("\n");
    const quote = ty === "opinion" || ty === "feature" ? `\n\n> "The details matter far more than the headline," one person close to the story told TrendoraNews.` : "";
    const body = [a.p[0], a.p[1], ctx[0], "## What to watch next", bullets, ctx[1]].join("\n\n") + quote;
    const country = a.cc ?? null;
    const region = country ? COUNTRY_MAP[country]?.region ?? null : null;
    const published = ago(a.h);
    const fs = a.fs ?? (["investigation", "news"].includes(ty) && rand() > 0.55 ? "verified" : "unchecked");
    const views = Math.round((600 + rand() * 9000) * (fl.includes("F") ? 2.2 : 1) * (a.h < 48 ? 1.4 : 1));
    return {
      slug: slugify(a.t.replace(/^(Live|Breaking|Special report|Editorial|Guest column|Fact check):\s*/i, (m) => m)),
      title: a.t,
      dek: a.d,
      body,
      coverImage: px(pool[idx % pool.length]),
      imageAlt: `${a.t} — illustrative photo`,
      imageCredit: "Pexels (stock photo)",
      category: a.c,
      subcategory: a.s,
      type: ty,
      country,
      region,
      tags,
      authorId: authorId[a.a],
      createdBy: editorUser.id,
      status: "published",
      isBreaking: fl.includes("B") || fl.includes("X"),
      breakingUntil: fl.includes("B") ? new Date(now + 3 * 86400_000) : fl.includes("X") ? ago(6) : null,
      isFeatured: fl.includes("F"),
      isEditorsChoice: fl.includes("E"),
      isDeveloping: fl.includes("D"),
      isLive: fl.includes("L"),
      publishedAt: published,
      createdAt: published,
      updatedAt: new Date(published.getTime() + (fl.includes("D") || fl.includes("L") ? Math.min(a.h * 0.8, 3) * 3600_000 : 600_000)),
      views,
      shares: Math.round(views * (0.03 + rand() * 0.08)),
      likes: Math.round(views * (0.02 + rand() * 0.06)),
      factStatus: fs,
      editorialLabel: a.lab ?? (fs === "verified" ? "Fact-checked" : i % 3 === 0 ? "Editor reviewed" : null),
      sources: [
        { title: "Official statements and primary documents (demo source)", url: `https://example.org/sources/${i + 1}` },
        { title: "Independent expert interviews", url: `https://example.org/experts/${i + 1}` },
      ],
      corrections: a.t.startsWith("Special report") ? [{ date: ago(10).toISOString(), note: "An earlier version misstated the number of collection points visited. The correct figure is 14, not 12." }] : [],
      readingMinutes: readingMinutes(body),
      version: 1,
      titleKey: titleKey(a.t),
    };
  });
  // unique slugs
  const seen = new Set<string>();
  for (const v of values) {
    let s = v.slug;
    let n = 2;
    while (seen.has(s)) s = `${v.slug}-${n++}`;
    seen.add(s);
    v.slug = s;
  }
  const artRows = await db.insert(articles).values(values).returning({ id: articles.id, slug: articles.slug, title: articles.title, body: articles.body, views: articles.views, isLive: articles.isLive, category: articles.category });
  const liveArticle = artRows.find((a) => a.isLive)!;

  // versions for a few articles
  await db.insert(articleVersions).values(
    artRows.slice(1, 6).flatMap((a) => [
      { articleId: a.id, version: 1, title: a.title, dek: "", body: a.body.split("\n\n").slice(0, 3).join("\n\n"), note: "Initial draft", editorName: "Rafiq Ahmed", createdAt: ago(30) },
      { articleId: a.id, version: 2, title: a.title, dek: "", body: a.body, note: "Edited for clarity; added context", editorName: "Imran Hossain", createdAt: ago(26) },
    ]),
  );

  // live updates
  const LIVE: [number, string, string, string, boolean][] = [
    [4, "Danger signal raised for coastal districts", "The weather department has hoisted the highest local warning signal for several coastal districts. Residents in low-lying areas are being urged to move to shelters immediately.", "alert", true],
    [18, "Fishing boats recalled", "Coast guard teams have recalled fishing trawlers from the sea. Hundreds of boats are anchored in river channels for shelter.", "update", false],
    [35, "Shelters open", "District administrations report that more than 1,000 cyclone shelters are open, with volunteers helping elderly residents and families with children.", "update", false],
    [62, "Transport suspended", "Ferry services and some inland flights have been suspended. Rail operators say services on coastal lines will stop from this evening.", "update", false],
    [95, "Correction: shelter count", "An earlier update gave an incorrect number of open shelters. The official figure at that time was 1,200, not 1,000.", "correction", false],
    [140, "Relief teams positioned", "Relief organisations have pre-positioned dry food, drinking water and medical supplies in district headquarters.", "update", false],
    [210, "Storm tracking update", "Forecasters say the system has intensified over warm water and is expected to move north-east towards the coast in the next 24 hours.", "update", false],
  ];
  await db.insert(liveUpdates).values(
    LIVE.map(([m, title, body, kind, pinned]) => ({ articleId: liveArticle.id, title, body, kind, pinned, authorName: "TrendoraNews Live Desk", createdAt: new Date(now - m * 60_000) })),
  );
  await db.insert(alerts).values([
    { level: "emergency", headline: "Storm warning: Danger signal raised for coastal districts — follow official shelter advice", articleId: liveArticle.id, active: true, expiresAt: new Date(now + 7 * 86400_000), createdAt: new Date(now - 4 * 60_000) },
    { level: "info", headline: "TrendoraNews Fact Check Center is now live — submit a claim for verification", articleId: null, active: false, expiresAt: null, createdAt: ago(100) },
  ]);

  // playlists + videos
  const pl = await db
    .insert(playlists)
    .values([
      { slug: "daily-briefing", title: "Daily Briefing", description: "Short, sharp video updates from the TrendoraNews desk." },
      { slug: "short-films-special", title: "Short Films Special", description: "Open-licence short films and animation curated by our entertainment desk." },
    ])
    .returning({ id: playlists.id, slug: playlists.slug });
  const plId = Object.fromEntries(pl.map((p) => [p.slug, p.id]));
  const v = (slug: string, title: string, description: string, file: string, dur: number, category: string, poster: number, playlist: string | null, order: number, featured: boolean, lines: string[], chapters: [number, string][], tags: string[], h: number) => ({
    slug, title, description, url: VBASE + file, poster: px(poster), durationSec: dur, category, playlistId: playlist ? plId[playlist] : null, playlistOrder: order, featured,
    views: Math.round(2000 + rand() * 40000), chapters: chapters.map(([t, tt]) => ({ t, title: tt })), cues: cuesFrom(lines, dur > 100 ? 8 : dur > 30 ? 6 : 3), tags, publishedAt: ago(h),
  });
  await db.insert(videos).values([
    v("morning-briefing-top-stories", "Morning Briefing: today's top stories in a flash", "A rapid-fire look at the stories shaping the day, from Dhaka to the world.", "ForBiggerBlazes.mp4", 15, "News", 11576092, "daily-briefing", 1, true,
      ["Good morning, this is your TrendoraNews briefing.", "Parliament passes the digital governance bill.", "Coastal districts prepare for the storm.", "Markets rise on strong chip earnings.", "That's the briefing — more on our live page."], [[0, "Headlines"], [6, "Bangladesh"], [11, "World & markets"]], ["briefing", "news"], 3),
    v("reporters-notebook-on-the-road", "Reporters' notebook: on the road with our field team", "Behind the scenes with reporters travelling to cover the story of the week.", "ForBiggerEscapes.mp4", 15, "Documentary", 10464468, "daily-briefing", 2, false,
      ["Field reporting means long roads and short deadlines.", "We verify every claim before it reaches you.", "Local guides make the story possible.", "Back at the desk, editors check each detail.", "Thanks for travelling with us."], [[0, "Departure"], [6, "On location"], [12, "Back at the desk"]], ["reporting", "behind the scenes"], 20),
    v("tech-weekly-gadgets-to-watch", "Tech Weekly: gadgets and ideas to watch", "Foldables, on-device AI and the gadgets worth your attention this week.", "ForBiggerFun.mp4", 60, "Technology", 2599244, "daily-briefing", 3, false,
      ["Welcome to Tech Weekly.", "On-device AI is going mainstream.", "Foldable phones keep getting cheaper.", "Battery tech is quietly improving.", "Startups turn waste into materials.", "Privacy is the big question to watch.", "Smarter sensors are arriving fast.", "Tools that save time deserve attention.", "Charging standards are converging.", "Thanks for watching Tech Weekly."], [[0, "Intro"], [12, "AI on your phone"], [24, "Foldables"], [42, "Startups to watch"]], ["technology", "gadgets"], 40),
    v("match-day-atmosphere", "Match-day atmosphere: inside the stadium", "Fans, flags and floodlights — the atmosphere before a big cricket match.", "ForBiggerJoyrides.mp4", 15, "Sports", 36293965, null, 0, true,
      ["Gates open three hours before the toss.", "Fans fill the stands with colour.", "Spin is expected to rule the day.", "The groundstaff make final checks.", "Play begins in minutes."], [[0, "Gates open"], [6, "The crowd"], [12, "Pitch report"]], ["cricket", "stadium"], 12),
    v("explainer-why-markets-wobble", "Explainer: why markets wobble", "A quick visual guide to why prices move when central banks speak.", "ForBiggerMeltdowns.mp4", 15, "Explainer", 7947709, null, 0, false,
      ["Markets are conversations about the future.", "A surprise word can move prices.", "Interest rates change the value of money.", "Volatility usually settles.", "Long-term investors stay calm."], [[0, "The basics"], [6, "Rates"], [12, "Staying calm"]], ["markets", "explainer"], 70),
    v("short-film-big-buck-bunny", "Short film: Big Buck Bunny (Blender Foundation)", "An open-licence animated short about a gentle rabbit and three mischievous rodents.", "BigBuckBunny.mp4", 596, "Short Film", 13218637, "short-films-special", 1, true,
      ["A quiet morning in the meadow.", "Butterflies and birdsong fill the air.", "Three troublemakers appear.", "Patience is tested.", "Revenge is planned carefully.", "The meadow is never quite the same."], [[0, "Morning"], [120, "Troublemakers"], [300, "The trap"], [480, "Finale"]], ["animation", "short film", "open licence"], 100),
    v("short-film-elephants-dream", "Short film: Elephants Dream (Blender Foundation)", "The first open movie: two characters explore a strange, machine-like world.", "ElephantsDream.mp4", 653, "Short Film", 34012639, "short-films-special", 2, false,
      ["Two travellers enter a vast machine.", "Nothing is quite what it seems.", "One believes, one doubts.", "Reality and illusion blur."], [[0, "Arrival"], [200, "Inside the machine"], [420, "Choice"]], ["animation", "short film"], 120),
    v("short-film-sintel", "Short film: Sintel (Blender Foundation)", "A young woman searches a harsh world for a lost companion.", "Sintel.mp4", 888, "Short Film", 30604060, "short-films-special", 3, false,
      ["A journey begins in the mountains.", "A small creature becomes a friend.", "Loss sets her on a long road.", "The search leads to a dragon's lair."], [[0, "Mountains"], [250, "Friendship"], [560, "The search"], [780, "Dragon's lair"]], ["animation", "short film"], 140),
  ]);

  // galleries
  const phot = await db.select({ id: authors.id, slug: authors.slug }).from(authors);
  const P = Object.fromEntries(phot.map((p) => [p.slug, p.id]));
  const img = (id: number, caption: string, alt: string, extra: Partial<GalleryImage> = {}): GalleryImage => ({ url: px(id, 1400, 900), caption, alt, credit: "Pexels", ...extra });
  const SEPIA = "grayscale(1) sepia(0.8) contrast(0.9) brightness(0.85)";
  await db.insert(galleries).values([
    { slug: "dhaka-after-dark", title: "Dhaka After Dark", description: "A photo story following the city as the lights come on — from foggy skylines to rain-slick streets.", kind: "photo_story", coverImage: px(32129353), photographerId: P["shahed-alam"], location: "Dhaka, Bangladesh", era: null, views: 5400, publishedAt: ago(30),
      images: [img(11576092, "Morning fog drapes the high-rises as the city wakes.", "Fog over Dhaka's skyline"), img(16428243, "By noon the streets are a river of umbrellas and rickshaws.", "Crowded street in Dhaka"), img(35097973, "The metro line cuts through the centre, lifting commuters above the traffic.", "Aerial view of Dhaka metro"), img(32129353, "After dark, the pavements belong to vendors, walkers and late-night tea stalls.", "Night street in Dhaka")] },
    { slug: "wild-frames-deer", title: "Wild Frames: Deer at the Edge of Light", description: "Four portraits of deer in forest, snow and sunset light.", kind: "gallery", coverImage: px(13218637), photographerId: P["mira-solberg"], location: "Northern Europe", era: null, views: 3900, publishedAt: ago(60),
      images: [img(13218637, "A deer pauses in dense forest foliage.", "Deer in forest"), img(16673916, "Sunlight breaks through a clearing.", "Deer in sunlit clearing"), img(30574311, "Silhouettes race across a hilltop at sunset.", "Deer silhouettes at sunset"), img(37352100, "A winter portrait in black and white.", "Black and white deer portrait")] },
    { slug: "edges-of-the-earth", title: "Edges of the Earth", description: "Fjords, cliffs and misty coastlines from the planet's wild margins.", kind: "gallery", coverImage: px(27797983), photographerId: P["mira-solberg"], location: "Faroe Islands & Norway", era: null, views: 4300, publishedAt: ago(80),
      images: [img(461955, "A seascape of mountains and a distant bridge.", "Mountains and sea"), img(3011841, "A fjord framed by towering cliffs.", "Fjord with cliffs"), img(27797983, "Misty cliffs in the Faroe Islands.", "Faroe Islands cliffs"), img(30604060, "Coastal peaks vanish into cloud.", "Misty coastal mountains")] },
    { slug: "restoring-history-before-after", title: "Restoring History: Before & After", description: "Drag the slider to compare a faded archival print with its digitally restored version.", kind: "before_after", coverImage: px(6422200), photographerId: P["tomas-rivera"], location: "Anatolia", era: "Restoration", views: 2800, publishedAt: ago(100),
      images: [img(6422200, "Before: faded, low-contrast archival print", "Faded print of ancient temple ruins", { filter: SEPIA }), img(6422200, "After: restored contrast and colour", "Restored colour photo of ancient temple ruins")] },
    { slug: "historical-photo-archive-ruins", title: "Historical Photo Archive: Ruins Through the Ages", description: "Archive-style prints tracing how photographers recorded ancient ruins across a century.", kind: "archive", coverImage: px(13507834), photographerId: P["tomas-rivera"], location: "Mediterranean", era: "1890s–1970s", views: 2100, publishedAt: ago(120),
      images: [img(13507834, "Columns at dusk, as recorded by a travelling photographer.", "Ruins in monochrome", { year: 1898, filter: SEPIA }), img(28243405, "Arched walls survey, expedition plate.", "Ruined arches", { year: 1924, filter: "grayscale(1) contrast(1.1)" }), img(6422200, "Temple columns with a visiting party.", "Temple columns", { year: 1951, filter: "sepia(0.7) brightness(0.9)" }), img(34672551, "Colour documentation for a survey.", "Fragmented stone columns", { year: 1977, filter: "saturate(0.7) contrast(0.95)" })] },
    { slug: "campus-then-and-now", title: "Campus Life, Then and Now", description: "Lecture halls and classrooms across generations.", kind: "archive", coverImage: px(8978622), photographerId: P["tomas-rivera"], location: "Various", era: "1950s–2020s", views: 1500, publishedAt: ago(150),
      images: [img(8978622, "A classroom in the mid-century.", "Students in classroom", { year: 1956, filter: "grayscale(1) contrast(1.05)" }), img(8197551, "A professor addresses a lecture group.", "Lecture hall", { year: 1998, filter: "saturate(0.6) sepia(0.2)" }), img(31367502, "Today's lecture halls are busier than ever.", "Modern lecture hall", { year: 2024 })] },
    { slug: "under-the-stage-lights", title: "Under the Stage Lights", description: "Seats, cameras and curtains — the quiet before the show.", kind: "gallery", coverImage: px(34518946), photographerId: P["shahed-alam"], location: "Various", era: null, views: 1800, publishedAt: ago(170),
      images: [img(17722682, "Empty rows wait in moody light.", "Empty auditorium seats"), img(34518946, "A cameraman balances his rig under coloured lights.", "Cameraman at stage event"), img(7991319, "Red seats in a cinema hall.", "Red cinema seats"), img(7991582, "Rows of seats before the film.", "Seats in movie theater")] },
    { slug: "match-day-in-frames", title: "Match Day in Frames", description: "Groundstaff, floodlights and the stands before play.", kind: "gallery", coverImage: px(36293966), photographerId: P["shahed-alam"], location: "Delhi", era: null, views: 2400, publishedAt: ago(190),
      images: [img(36293965, "Players and spectators under clear skies.", "Cricket match in Delhi"), img(37364347, "A stadium surrounded by greenery.", "Aerial view of stadium"), img(36293964, "Groundstaff roll the pitch at sunset.", "Groundstaff preparing cricket field"), img(36293966, "Floodlights and a full day's play.", "Daytime cricket match")] },
  ]);

  // media library
  const media: [string, string, string, string, number, number, string][] = [
    ["image", "Dhaka skyline in fog", px(11576092), "Fog over Dhaka's high-rise skyline", 1200, 627, "dhaka,city"],
    ["image", "Cricket match in Delhi", px(36293965), "Cricket match with players and spectators", 1200, 627, "cricket,sports"],
    ["image", "Andromeda galaxy", px(40074430), "Andromeda galaxy in deep space", 1200, 627, "space,galaxy"],
    ["image", "Deer in forest", px(13218637), "A deer standing in dense forest", 1200, 627, "wildlife,deer"],
    ["image", "Press interview", px(33317197), "Spokesperson giving press interview outdoors", 1200, 627, "press,interview"],
    ["image", "Stock chart", px(35118208), "", 1200, 627, "markets,finance"],
    ["image", "Parliament chamber", px(32266781), "", 1200, 627, "politics,parliament"],
  ];
  await db.insert(mediaAssets).values([
    ...media.map(([kind, title, url, alt, w, h, tags], i) => ({ kind, title, url, altText: alt, width: w, height: h, mime: "image/jpeg", sizeBytes: 180000 + i * 13000, hash: `seed-${i}`, tags: tags.split(","), credit: "Pexels", uploadedBy: "Seed" })),
    { kind: "video", title: "Morning briefing clip", url: VBASE + "ForBiggerBlazes.mp4", mime: "video/mp4", sizeBytes: 2500000, hash: "seed-v1", altText: "Short news briefing clip", tags: ["video", "briefing"], uploadedBy: "Seed" },
    { kind: "video", title: "Match day clip", url: VBASE + "ForBiggerJoyrides.mp4", mime: "video/mp4", sizeBytes: 2300000, hash: "seed-v2", altText: "Match day atmosphere clip", tags: ["video", "sports"], uploadedBy: "Seed" },
    { kind: "audio", title: "Podcast intro jingle", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", mime: "audio/mpeg", sizeBytes: 5400000, hash: "seed-a1", altText: "Instrumental jingle", tags: ["audio", "podcast"], uploadedBy: "Seed" },
    { kind: "audio", title: "Background bed — newsroom", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3", mime: "audio/mpeg", sizeBytes: 6100000, hash: "seed-a2", altText: "Instrumental background track", tags: ["audio", "bed"], uploadedBy: "Seed" },
  ]);

  // fact checks
  await db.insert(factChecks).values([
    ...FACT_CHECKS.map((f, i) => ({ ...f, sources: [{ title: "Peer-reviewed literature and expert interviews", url: `https://example.org/fact/${i + 1}` }], status: "published", createdAt: ago(10 + i * 14) })),
    ...SUBMITTED_CLAIMS.map((c) => ({ claim: c, verdict: "unproven", explanation: "", sources: [], status: "submitted", submittedBy: "reader@trendora.news", category: null, checkedBy: null, createdAt: ago(5) })),
  ]);

  // comments, bookmarks, follows, history, notifications
  const bySlug = (frag: string) => artRows.find((a) => a.slug.includes(frag))!;
  const cs = [bySlug("digital-governance-bill"), bySlug("tiger-census"), bySlug("metro")];
  await db.insert(comments).values([
    { articleId: cs[0].id, userId: reader.id, body: "Good to see a data-protection authority — hope it gets real independence.", createdAt: ago(2) },
    { articleId: cs[0].id, userId: userRows[3].id, body: "Agree. The review clause on exemptions will be the one to watch.", createdAt: ago(1.5) },
    { articleId: cs[1].id, userId: reader.id, body: "Wonderful news for the Sundarbans. More funding for rangers please!", createdAt: ago(4) },
    { articleId: cs[2].id, userId: userRows[6].id, body: "The feeder-bus point is spot on — walking from the station is still tough.", createdAt: ago(12) },
    { articleId: liveArticle.id, userId: reader.id, body: "Staying safe everyone. Thanks for the clear updates.", createdAt: ago(0.3) },
  ]);
  await db.insert(bookmarks).values([cs[0], cs[1], bySlug("telescope")].map((a) => ({ userId: reader.id, articleId: a.id })));
  await db.insert(follows).values([
    { userId: reader.id, kind: "category", target: "technology" },
    { userId: reader.id, kind: "category", target: "bangladesh" },
    { userId: reader.id, kind: "category", target: "science" },
    { userId: reader.id, kind: "author", target: "maya-fernandes" },
  ]);
  await db.insert(readingHistory).values([cs[0], cs[2], bySlug("rice-variety")].map((a, i) => ({ userId: reader.id, articleId: a.id, progress: [100, 64, 35][i], seconds: [140, 80, 40][i], viewedAt: ago(i * 5 + 1) })));
  await db.insert(notifications).values(
    userRows.flatMap((u) => [
      { userId: u.id, title: "Storm warning for coastal districts", body: "Follow our live page for verified updates.", href: `/news/${liveArticle.slug}`, kind: "emergency", read: false, createdAt: ago(0.07) },
      { userId: u.id, title: "Welcome to TrendoraNews", body: "Personalise your feed by following categories and authors.", href: "/dashboard?tab=following", kind: "info", read: u.role !== "reader", createdAt: ago(48) },
    ]),
  );
  await db.insert(subscribers).values(
    ["rina@example.com", "karim@example.com", "tania@example.org", "john@example.net", "li.wei@example.com", "amina@example.com", "sam@example.org", "noor@example.com", "ivan@example.net", "fatima@example.com", "reader@trendora.news", "dev@example.com"].map((email, i) => ({ email, topics: i % 2 ? ["bangladesh", "technology"] : ["world", "business"], createdAt: ago(i * 55) })),
  );

  // search logs
  const logs: { query: string; results: number; createdAt: Date }[] = [];
  for (const [q, n] of SEARCH_QUERIES) for (let i = 0; i < n; i++) logs.push({ query: q, results: 1 + Math.floor(rand() * 8), createdAt: ago(rand() * 24 * 14) });
  logs.push({ query: "quantum teleportation", results: 0, createdAt: ago(5) }, { query: "mars colony", results: 0, createdAt: ago(40) });
  await db.insert(searchLogs).values(logs);

  // analytics events
  const countries = ["BD", "BD", "BD", "BD", "IN", "IN", "US", "GB", "AE", "SA", "CA", "AU", "DE", "MY", "SG", "PK", "NP", "JP"];
  const sources = ["Direct", "Google", "Google", "Google", "Facebook", "Facebook", "X / Twitter", "Newsletter", "Bing", "Referral", "YouTube"];
  const devices = ["Mobile", "Mobile", "Mobile", "Mobile", "Desktop", "Desktop", "Tablet"];
  const visitors = Array.from({ length: 520 }, (_, i) => `v${i}`);
  const sortedArts = [...artRows].sort((a, b) => b.views - a.views);
  const evRows: (typeof events.$inferInsert)[] = [];
  for (let i = 0; i < 3600; i++) {
    const dayBias = Math.pow(rand(), 1.4); // more recent days heavier
    const created = new Date(now - dayBias * 30 * 86400_000 - rand() * 3600_000);
    const roll = rand();
    const vis = visitors[Math.floor(Math.pow(rand(), 1.6) * visitors.length)];
    const country = countries[Math.floor(rand() * countries.length)];
    const base = { visitorId: vis, country, device: devices[Math.floor(rand() * devices.length)], source: sources[Math.floor(rand() * sources.length)], isReturning: rand() < 0.38, createdAt: created } as const;
    if (roll < 0.78) {
      const a = sortedArts[Math.floor(Math.pow(rand(), 1.8) * sortedArts.length)];
      evRows.push({ ...base, type: "pageview", path: `/news/${a.slug}`, articleId: a.id, category: a.category });
      if (rand() < 0.55) evRows.push({ ...base, type: "read", path: `/news/${a.slug}`, articleId: a.id, category: a.category, seconds: 35 + Math.floor(rand() * 260) });
    } else if (roll < 0.9) {
      evRows.push({ ...base, type: "pageview", path: "/", category: null });
    } else {
      evRows.push({ ...base, type: "video_view", path: "/videos", videoId: 1 + Math.floor(rand() * 8), category: "video" });
    }
  }
  for (let i = 0; i < 14; i++) {
    const a = sortedArts[i % 6];
    evRows.push({ visitorId: `live${i}`, type: "pageview", path: `/news/${a.slug}`, articleId: a.id, category: a.category, country: countries[i], device: devices[i % 7], source: sources[i % 11], isReturning: i % 3 === 0, createdAt: new Date(now - rand() * 4 * 60_000) });
  }
  for (let i = 0; i < evRows.length; i += 500) await db.insert(events).values(evRows.slice(i, i + 500));
}
