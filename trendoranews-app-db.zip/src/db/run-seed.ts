import "dotenv/config";

async function main() {
  const { runSeed } = await import("./seed");
  await runSeed();
  console.log("Seed complete");
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
